import React from 'react';
import {Composition} from 'remotion';
import {SandalVideo} from './Video';
import {FPS, HEIGHT, TOTAL_FRAMES, WIDTH} from './data/beats';

export const RemotionRoot: React.FC = () => {
  return (
    <Composition
      id="SandalSebelah"
      component={SandalVideo}
      durationInFrames={TOTAL_FRAMES}
      fps={FPS}
      width={WIDTH}
      height={HEIGHT}
    />
  );
};
