import React from 'react';

/** Sandal jepit biru tua — SATU bentuk master dipakai di semua adegan (konsistensi). */
export const SANDAL = {
  sole: '#1F3F9C',
  soleLight: '#2C52BE',
  edge: '#10286E',
  strap: '#3F6FE0',
  strapDark: '#1B3A8F',
  ink: '#0B1230',
};

/** Outline sol (kepala/jempol di atas, panjang 170, lebar ±38). Dipakai juga oleh Footprint. */
export const SOLE_PATH =
  'M 0,-85 C 34,-85 40,-52 36,-10 C 33,28 30,60 18,78 C 8,90 -8,90 -18,78 C -30,60 -33,28 -36,-10 C -40,-52 -34,-85 0,-85 Z';

type SandalProps = {
  x?: number;
  y?: number;
  rot?: number;
  scale?: number;
  /** Penggepengan vertikal untuk sandal yang tergeletak di lantai berperspektif (1 = tampak atas). */
  tilt?: number;
  thick?: number;
  /** Tampilkan kaki krem di dalam sandal (dipakai saat sandal dikenakan). */
  foot?: boolean;
  opacity?: number;
  /** Warna lain hanya untuk sandal pajangan di toko. Sandal cerita selalu biru tua (default). */
  colors?: Partial<typeof SANDAL>;
};

export const Sandal: React.FC<SandalProps> = ({x = 0, y = 0, rot = 0, scale = 1, tilt = 1, thick = 12, foot = false, opacity = 1, colors}) => {
  const C = {...SANDAL, ...colors};
  return (
  <g transform={`translate(${x},${y}) scale(1,${tilt}) rotate(${rot}) scale(${scale})`} opacity={opacity}>
    <path d={SOLE_PATH} transform={`translate(0,${thick})`} fill={C.edge} stroke={C.ink} strokeWidth={7} strokeLinejoin="round" />
    <path d={SOLE_PATH} fill={C.sole} stroke={C.ink} strokeWidth={7} strokeLinejoin="round" />
    <path d={SOLE_PATH} transform="scale(0.8)" fill={C.soleLight} opacity={0.85} />
    {foot && <ellipse cx={0} cy={8} rx={25} ry={58} fill="#F2D9C2" stroke={C.ink} strokeWidth={5} />}
    {/* tali Y: dua tali samping bertemu di tiang jempol */}
    <path d="M -33,-6 Q -14,-30 0,-56 Q 14,-30 33,-6" fill="none" stroke={C.ink} strokeWidth={21} strokeLinecap="round" strokeLinejoin="round" />
    <path d="M -33,-6 Q -14,-30 0,-56 Q 14,-30 33,-6" fill="none" stroke={C.strap} strokeWidth={13} strokeLinecap="round" strokeLinejoin="round" />
    <circle cx={0} cy={-56} r={9} fill={C.strapDark} stroke={C.ink} strokeWidth={4} />
  </g>
  );
};

/** Pasangan sandal berdiri berdampingan (dipegang di Beat 3). */
export const SandalPair: React.FC<{x?: number; y?: number; rot?: number; scale?: number}> = ({x = 0, y = 0, rot = 0, scale = 1}) => (
  <g transform={`translate(${x},${y}) rotate(${rot}) scale(${scale})`}>
    <Sandal x={-44} y={0} rot={-6} />
    <Sandal x={44} y={0} rot={6} />
  </g>
);
