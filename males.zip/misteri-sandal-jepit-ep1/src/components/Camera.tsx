import React, {createContext, useContext} from 'react';
import {AbsoluteFill} from 'remotion';
import {HEIGHT, WIDTH} from '../data/beats';
import {EaseName, ease, lerp, useSceneTime} from '../utils/anim';

/**
 * Kamera 2.5D: layer dengan `depth` berbeda bergeser berbeda (parallax) dan di-zoom berbeda.
 *  depth 0   = langit/jauh (hampir diam)
 *  depth 1   = bidang karakter (bergerak penuh mengikuti kamera)
 *  depth >1  = foreground (bergerak lebih cepat, blur ringan bila diinginkan)
 */
export type CamKey = {t: number; cx?: number; cy?: number; zoom?: number; rot?: number; ease?: EaseName};
export type CamState = {cx: number; cy: number; zoom: number; rot: number};

const CamCtx = createContext<CamState>({cx: WIDTH / 2, cy: HEIGHT / 2, zoom: 1, rot: 0});
export const useCam = (): CamState => useContext(CamCtx);

type Filled = {t: number; ease: EaseName; s: CamState};
const fill = (keys: CamKey[]): Filled[] => {
  let p: CamState = {cx: WIDTH / 2, cy: HEIGHT / 2, zoom: 1, rot: 0};
  return keys.map((k) => {
    p = {cx: k.cx ?? p.cx, cy: k.cy ?? p.cy, zoom: k.zoom ?? p.zoom, rot: k.rot ?? p.rot};
    return {t: k.t, ease: k.ease ?? 'io', s: p};
  });
};

export function sampleCam(keys: CamKey[], t: number): CamState {
  const ks = fill(keys);
  if (t <= ks[0].t) return ks[0].s;
  for (let i = 1; i < ks.length; i++) {
    if (t <= ks[i].t) {
      const a = ks[i - 1].s;
      const b = ks[i].s;
      const k = ease(ks[i].ease, (t - ks[i - 1].t) / Math.max(1e-6, ks[i].t - ks[i - 1].t));
      return {cx: lerp(a.cx, b.cx, k), cy: lerp(a.cy, b.cy, k), zoom: lerp(a.zoom, b.zoom, k), rot: lerp(a.rot, b.rot, k)};
    }
  }
  return ks[ks.length - 1].s;
}

type CameraProps = {
  keys: CamKey[];
  /** Amplitudo guncangan handheld (px). 0 = mati. Deterministik (sinus berbasis frame). */
  handheld?: number;
  /** Blur gerak otomatis saat kamera bergerak sangat cepat (whip pan). */
  motionBlur?: boolean;
  children?: React.ReactNode;
};

export const Camera: React.FC<CameraProps> = ({keys, handheld = 0, motionBlur = true, children}) => {
  const {f, t, fps} = useSceneTime();
  const s = sampleCam(keys, t);
  const prev = sampleCam(keys, Math.max(0, t - 1 / fps));
  const hx = handheld * (Math.sin(f * 0.37) + 0.6 * Math.sin(f * 0.91 + 2));
  const hy = handheld * (0.8 * Math.sin(f * 0.29 + 1) + 0.5 * Math.sin(f * 0.77));
  const hr = handheld * 0.018 * Math.sin(f * 0.23);
  const state: CamState = {cx: s.cx + hx, cy: s.cy + hy, zoom: s.zoom, rot: s.rot + hr};
  const vel = Math.hypot(s.cx - prev.cx, s.cy - prev.cy);
  const blur = motionBlur ? Math.min(28, Math.max(0, (vel - 22) * 0.3)) : 0;
  return (
    <AbsoluteFill style={{overflow: 'hidden', filter: blur > 0.5 ? `blur(${blur.toFixed(1)}px)` : undefined}}>
      <CamCtx.Provider value={state}>{children}</CamCtx.Provider>
    </AbsoluteFill>
  );
};

type LayerProps = {
  depth?: number;
  blur?: number;
  style?: React.CSSProperties;
  children?: React.ReactNode;
};

/** Satu lapisan ruang: ukuran kanvas penuh, bergeser/zoom sesuai kedalaman. */
export const Layer: React.FC<LayerProps> = ({depth = 1, blur = 0, style, children}) => {
  const c = useCam();
  const zf = 0.6 + 0.4 * depth;
  const z = 1 + (c.zoom - 1) * zf;
  const ox = c.cx - WIDTH / 2;
  const oy = c.cy - HEIGHT / 2;
  return (
    <div
      style={{
        position: 'absolute',
        left: 0,
        top: 0,
        width: WIDTH,
        height: HEIGHT,
        transformOrigin: '0 0',
        transform: `translate(${WIDTH / 2}px, ${HEIGHT / 2}px) rotate(${c.rot * depth}deg) scale(${z}) translate(${-WIDTH / 2 - ox * depth}px, ${-HEIGHT / 2 - oy * depth}px)`,
        filter: blur > 0 ? `blur(${blur}px)` : undefined,
        ...style,
      }}
    >
      {children}
    </div>
  );
};

/** Overlay layar penuh yang tidak ikut kamera (vignette, tint, dll.). */
export const Overlay: React.FC<{style?: React.CSSProperties; children?: React.ReactNode}> = ({style, children}) => (
  <div style={{position: 'absolute', left: 0, top: 0, width: WIDTH, height: HEIGHT, pointerEvents: 'none', ...style}}>{children}</div>
);
