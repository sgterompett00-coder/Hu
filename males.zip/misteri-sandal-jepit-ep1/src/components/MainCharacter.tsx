import React from 'react';
import {Sandal} from './Sandal';
import {clamp, ease, lerp} from '../utils/anim';

/**
 * Karakter utama — rig 2D vektor (SVG). Tidak pernah 3D.
 * Sistem koordinat rig: titik (0,0) = tengah telapak kaki di tanah, y negatif = ke atas.
 * Sudut: 0 = lurus ke bawah, POSITIF = ayun ke depan (arah hadap, +x). dir=-1 membalik karakter.
 */
export const INK = '#0B0B0F';
export const HOOD = '#C9CED8';
export const HOOD_SHADE = '#A4ABB8';
export const SKIN = '#F2D9C2';
const UA = 66; // panjang lengan atas (lengan hoodie)
const FA = 72; // panjang lengan bawah sampai pusat tangan

/* ------------------------------ EKSPRESI ------------------------------ */
export type ExprName =
  | 'neutral' | 'confident' | 'smug' | 'curious' | 'confused' | 'suspicious' | 'thinking'
  | 'happy' | 'laughing' | 'shocked' | 'nervous' | 'scared' | 'panicked';

export type Expr = {
  eyeR: number; lid: number; pupil: number; px: number; py: number; arc: number;
  bAng: number; bYL: number; bYR: number;
  mW: number; mTop: number; mBot: number; mY: number; mSkew: number; sweat: number;
};
const E = (o: Partial<Expr>): Expr => ({
  eyeR: 28, lid: 0.1, pupil: 8, px: 0, py: 0, arc: 0, bAng: 0, bYL: 0, bYR: 0,
  mW: 22, mTop: 6, mBot: 8, mY: 66, mSkew: 0, sweat: 0, ...o,
});
export const EXPR: Record<ExprName, Expr> = {
  neutral: E({}),
  confident: E({lid: 0.28, bAng: 8, bYL: -2, bYR: -2, mW: 32, mTop: 20, mBot: 25, mSkew: -6, px: 0.15}),
  smug: E({lid: 0.5, bAng: 12, bYR: -9, mW: 36, mTop: 16, mBot: 21, mSkew: -14, px: 0.3, py: 0.1}),
  curious: E({eyeR: 30, lid: 0, pupil: 9, bAng: -6, bYL: -12, bYR: -3, px: 0.4, py: -0.3, mW: 14, mTop: 2, mBot: 14, mY: 68}),
  confused: E({eyeR: 30, lid: 0.05, pupil: 7, bAng: -14, bYL: -8, bYR: 2, px: -0.4, mW: 24, mTop: 4, mBot: 5, mSkew: 10, mY: 68}),
  suspicious: E({eyeR: 26, lid: 0.5, pupil: 7, bAng: 20, bYL: 2, bYR: 2, px: 0.6, mW: 22, mTop: 2, mBot: 3, mSkew: 3, mY: 68}),
  thinking: E({lid: 0.25, bAng: 4, bYL: -10, px: 0.5, py: -0.6, mW: 16, mTop: 6, mBot: 8, mSkew: 8, mY: 70}),
  happy: E({lid: 0.05, pupil: 9, bAng: -4, bYL: -9, bYR: -9, mW: 40, mTop: 12, mBot: 56, mY: 60}),
  laughing: E({arc: 1, bAng: -6, bYL: -8, bYR: -8, mW: 46, mTop: 4, mBot: 76, mY: 58}),
  shocked: E({eyeR: 38, lid: 0, pupil: 5, bAng: -10, bYL: -22, bYR: -22, mW: 22, mTop: -34, mBot: 62, mY: 70}),
  nervous: E({lid: 0.1, pupil: 7, bAng: -16, bYL: -8, bYR: -8, px: -0.6, mW: 24, mTop: 4, mBot: 8, mSkew: 4, sweat: 0.8}),
  scared: E({eyeR: 34, lid: 0, pupil: 5, bAng: -22, bYL: -16, bYR: -16, mW: 26, mTop: 0, mBot: 44, mY: 68, sweat: 1}),
  panicked: E({eyeR: 40, lid: 0, pupil: 4, bAng: -26, bYL: -24, bYR: -24, mW: 32, mTop: -14, mBot: 70, mY: 66, sweat: 1}),
};

export const lerpExpr = (a: Expr, b: Expr, k: number): Expr => {
  const o = {} as Expr;
  (Object.keys(a) as Array<keyof Expr>).forEach((key) => {
    o[key] = lerp(a[key], b[key], k);
  });
  return o;
};

/** Ekspresi berubah mengikuti keyframe [detik, nama]; transisi halus selama `blend` detik. */
export function exprTrack(t: number, keys: Array<[number, ExprName]>, blend = 0.18): Expr {
  let i = 0;
  for (let n = 0; n < keys.length; n++) if (t >= keys[n][0]) i = n;
  const cur = EXPR[keys[i][1]];
  if (i > 0 && t - keys[i][0] < blend) {
    return lerpExpr(EXPR[keys[i - 1][1]], cur, ease('io', (t - keys[i][0]) / blend));
  }
  return cur;
}

/* -------------------------------- POSE -------------------------------- */
export type Pose = {
  hipY: number; lean: number; headRot: number; headDy: number;
  legL: [number, number]; legR: [number, number]; armL: [number, number]; armR: [number, number];
};
export const basePose = (): Pose => ({
  hipY: 0, lean: 0, headRot: 0, headDy: 0, legL: [0, 0], legR: [0, 0], armL: [4, 8], armR: [-4, 8],
});
export const blendPose = (a: Pose, b: Pose, k: number): Pose => {
  const p2 = (x: [number, number], y: [number, number]): [number, number] => [lerp(x[0], y[0], k), lerp(x[1], y[1], k)];
  return {
    hipY: lerp(a.hipY, b.hipY, k), lean: lerp(a.lean, b.lean, k), headRot: lerp(a.headRot, b.headRot, k),
    headDy: lerp(a.headDy, b.headDy, k), legL: p2(a.legL, b.legL), legR: p2(a.legR, b.legR),
    armL: p2(a.armL, b.armL), armR: p2(a.armR, b.armR),
  };
};
export const poseIdle = (f: number): Pose => ({
  ...basePose(),
  hipY: Math.sin(f * 0.18) * 1.2,
  lean: Math.sin(f * 0.09) * 1.2,
  headRot: Math.sin(f * 0.07) * 1.5,
  armL: [2 + Math.sin(f * 0.09) * 2, 6],
  armR: [-2 - Math.sin(f * 0.09) * 2, 6],
});
export const poseWalk = (f: number, speed = 0.22): Pose => {
  const p = f * speed;
  const s = Math.sin(p);
  const c = Math.cos(p);
  return {
    hipY: -Math.abs(c) * 6, lean: 3, headRot: Math.sin(p * 2) * 1.2, headDy: Math.abs(c) * 1.5,
    legL: [s * 26, -(0.5 + 0.5 * Math.cos(p + 0.5)) * 30],
    legR: [-s * 26, -(0.5 + 0.5 * Math.cos(p + 0.5 + Math.PI)) * 30],
    armL: [-s * 24, 12], armR: [s * 24, 12],
  };
};
/** Kaki selalu menapak tanah: hitung sudut tulang kering dari tinggi pinggul. */
const groundedLeg = (hipY: number, thighDeg: number): [number, number] => {
  const H = 220 - hipY;
  const c = clamp((H - 110 * Math.cos((thighDeg * Math.PI) / 180)) / 110, -1, 1);
  const shinAbs = (-Math.acos(c) * 180) / Math.PI;
  return [thighDeg, shinAbs - thighDeg];
};
export const poseCrouch = (k: number): Pose => {
  const hipY = 95 * k;
  return {
    ...basePose(), hipY, lean: 24 * k, headRot: -6 * k,
    legL: groundedLeg(hipY, 60 * k), legR: groundedLeg(hipY, 52 * k),
    armL: [20 * k, 30 * k], armR: [34 * k, 40 * k],
  };
};
/** Duduk di lantai, kaki lurus ke depan (arah hadap). */
export const poseFloorSit = (): Pose => ({
  ...basePose(), hipY: 212, lean: 2, legL: [88, -6], legR: [84, -6], armL: [10, 20], armR: [10, 20],
});
export const poseSit = (): Pose => ({
  ...basePose(), hipY: 106, lean: 4, legL: groundedLeg(106, 88), legR: groundedLeg(106, 84),
  armL: [10, 20], armR: [10, 20],
});

/* ---------------------------- FORWARD KINEMATICS ---------------------------- */
export type CharXform = {x: number; y: number; scale?: number; dir?: 1 | -1};
/** Posisi dunia ujung lengan (+extra px di sepanjang lengan bawah) dan arah (derajat, 0 = +x, 90 = bawah). */
export function armTip(c: CharXform, pose: Pose, side: 'L' | 'R', extra = 0): {x: number; y: number; angle: number} {
  const r = Math.PI / 180;
  const sx = side === 'L' ? -96 : 96;
  const a = side === 'L' ? pose.armL : pose.armR;
  const ex = sx + UA * Math.sin(a[0] * r);
  const ey = -392 + UA * Math.cos(a[0] * r);
  const A = (a[0] + a[1]) * r;
  const hx = ex + (FA + extra) * Math.sin(A);
  const hy = ey + (FA + extra) * Math.cos(A);
  const th = pose.lean * r;
  const rot = (px: number, py: number): [number, number] => {
    const dx = px;
    const dy = py + 220;
    return [dx * Math.cos(th) - dy * Math.sin(th), dx * Math.sin(th) + dy * Math.cos(th) - 220];
  };
  const [rx, ry] = rot(hx, hy);
  const vx = Math.sin(A) * Math.cos(th) - Math.cos(A) * Math.sin(th);
  const vy = Math.sin(A) * Math.sin(th) + Math.cos(A) * Math.cos(th);
  const s = c.scale ?? 1;
  const d = c.dir ?? 1;
  return {x: c.x + d * s * rx, y: c.y + s * (ry + pose.hipY), angle: (Math.atan2(s * vy, d * s * vx) * 180) / Math.PI};
}

/* -------------------------------- RAMBUT -------------------------------- */
const R = 130;
const pt = (deg: number, rad: number): string => `${(rad * Math.cos((deg * Math.PI) / 180)).toFixed(1)},${(-rad * Math.sin((deg * Math.PI) / 180)).toFixed(1)}`;
const SPIKES: Array<[number, number]> = [[166, 160], [148, 205], [128, 180], [108, 220], [88, 192], [68, 216], [48, 184], [30, 200], [13, 158]];
const spikePath = (): string => {
  let d = `M ${pt(172, R + 2)}`;
  SPIKES.forEach(([a, tip], i) => {
    d += ` L ${pt(a + 5, R + 6)} L ${pt(a, tip)}`;
    const next = SPIKES[i + 1];
    d += next ? ` L ${pt((a + next[0]) / 2, R + 12)}` : ` L ${pt(a - 5, R + 6)}`;
  });
  return d;
};
const HAIR_FRONT = `${spikePath()} L ${pt(8, R)} L 126,-18 L 112,-54 L 96,-44 L 84,-78 L 60,-64 L 44,-96 L 20,-72 L 0,-100 L -22,-74 L -46,-96 L -64,-62 L -86,-78 L -98,-46 L -114,-56 L -126,-20 Z`;
const HAIR_BACK = `${spikePath()} L ${pt(-6, R)} L 126,18 L 100,46 L 70,32 L 40,54 L 10,36 L -20,56 L -50,34 L -80,50 L -106,30 L -126,16 Z`;
const HAIR_LIGHTS = ['M -60,-150 L -40,-170', 'M -10,-168 L 8,-196', 'M 52,-150 L 70,-176', 'M 100,-98 L 112,-118'];

/* --------------------------------- WAJAH --------------------------------- */
const Eye: React.FC<{cx: number; cy: number; e: Expr}> = ({cx, cy, e}) => {
  const r = e.eyeR;
  if (e.arc > 0.5) {
    return <path d={`M ${cx - r * 0.9} ${cy + 8} Q ${cx} ${cy - r * 1.25} ${cx + r * 0.9} ${cy + 8}`} fill="none" stroke={INK} strokeWidth={8} strokeLinecap="round" />;
  }
  const lidY = -r + e.lid * 2 * r;
  const w = Math.sqrt(Math.max(0, r * r - lidY * lidY));
  const pr = Math.min(e.pupil, r * 0.5);
  const pcy = Math.min(r - pr - 2, Math.max(e.py * r * 0.3, lidY + pr + 3));
  return (
    <g transform={`translate(${cx},${cy})`}>
      {e.lid < 0.03 ? (
        <circle r={r} fill="#fff" stroke={INK} strokeWidth={7} />
      ) : (
        <path d={`M ${-w} ${lidY} L ${w} ${lidY} A ${r} ${r} 0 ${lidY < 0 ? 1 : 0} 1 ${-w} ${lidY} Z`} fill="#fff" stroke={INK} strokeWidth={7} strokeLinejoin="round" />
      )}
      <circle cx={e.px * r * 0.5} cy={pcy} r={pr} fill={INK} />
    </g>
  );
};

const Face: React.FC<{e: Expr}> = ({e}) => {
  const open = clamp((e.mBot - e.mTop - 8) / 14);
  return (
    <g>
      <Eye cx={-46} cy={4} e={e} />
      <Eye cx={46} cy={4} e={e} />
      <g transform={`translate(-46,${-34 + e.bYL}) rotate(${e.bAng})`}>
        <line x1={-24} y1={0} x2={24} y2={0} stroke={INK} strokeWidth={10} strokeLinecap="round" />
      </g>
      <g transform={`translate(46,${-34 + e.bYR}) rotate(${-e.bAng})`}>
        <line x1={-24} y1={0} x2={24} y2={0} stroke={INK} strokeWidth={10} strokeLinecap="round" />
      </g>
      <path
        transform={`translate(0,${e.mY})`}
        d={`M ${-e.mW} 0 Q 0 ${e.mTop} ${e.mW} ${e.mSkew} Q 0 ${e.mBot} ${-e.mW} 0 Z`}
        fill="#5B1220" fillOpacity={open} stroke={INK} strokeWidth={7} strokeLinejoin="round" strokeLinecap="round"
      />
      {e.sweat > 0.02 && (
        <path d="M 112,-48 Q 134,-12 112,6 Q 90,-12 112,-48 Z" fill="#8ED8FF" stroke={INK} strokeWidth={5} opacity={clamp(e.sweat)} />
      )}
    </g>
  );
};

/* -------------------------------- ANGGOTA -------------------------------- */
const Foot: React.FC<{kind: 'sandal' | 'bare' | 'none'}> = ({kind}) => {
  if (kind === 'none') return null;
  if (kind === 'sandal') return <Sandal x={14} y={8} rot={90} scale={0.5} tilt={0.85} foot thick={8} />;
  return (
    <g transform="translate(14,8)">
      <ellipse cx={0} cy={0} rx={40} ry={14} fill={SKIN} stroke={INK} strokeWidth={5} />
      {[-7, -1, 5, 10].map((y, i) => (
        <circle key={i} cx={38 - Math.abs(y) * 0.4} cy={y} r={5.5 - i * 0.3} fill={SKIN} stroke={INK} strokeWidth={3} />
      ))}
    </g>
  );
};

const Leg: React.FC<{hx: number; hy: number; a: [number, number]; foot: 'sandal' | 'bare' | 'none'}> = ({hx, hy, a, foot}) => (
  <g transform={`translate(${hx},${hy}) rotate(${-a[0]})`}>
    <line x1={0} y1={0} x2={0} y2={110} stroke={INK} strokeWidth={18} strokeLinecap="round" />
    <g transform={`translate(0,110) rotate(${-a[1]})`}>
      <line x1={0} y1={0} x2={0} y2={110} stroke={INK} strokeWidth={18} strokeLinecap="round" />
      <g transform={`translate(0,110) rotate(${a[0] + a[1]})`}>
        <Foot kind={foot} />
      </g>
    </g>
  </g>
);

const Flashlight: React.FC<{on: boolean}> = ({on}) => (
  <g>
    <rect x={-11} y={58} width={22} height={52} rx={6} fill="#4A4F5C" stroke={INK} strokeWidth={5} />
    <path d="M -14,104 L 14,104 L 21,130 L -21,130 Z" fill="#6B7180" stroke={INK} strokeWidth={5} strokeLinejoin="round" />
    <ellipse cx={0} cy={130} rx={19} ry={6} fill={on ? '#FFF3A6' : '#9AA0AE'} stroke={INK} strokeWidth={4} />
  </g>
);

const Arm: React.FC<{sx: number; a: [number, number]; light?: boolean; lightOn?: boolean}> = ({sx, a, light, lightOn = true}) => (
  <g transform={`translate(${sx},-392) rotate(${-a[0]})`}>
    <line x1={0} y1={0} x2={0} y2={UA - 4} stroke={INK} strokeWidth={42} strokeLinecap="round" />
    <line x1={0} y1={0} x2={0} y2={UA - 4} stroke={HOOD} strokeWidth={31} strokeLinecap="round" />
    <g transform={`translate(0,${UA}) rotate(${-a[1]})`}>
      <line x1={0} y1={0} x2={0} y2={FA} stroke={INK} strokeWidth={15} strokeLinecap="round" />
      {light && <Flashlight on={lightOn} />}
      <circle cx={0} cy={FA} r={18} fill={INK} />
    </g>
  </g>
);

/* ------------------------------- KOMPONEN ------------------------------- */
export type CharProps = {
  x: number; y: number; scale?: number; dir?: 1 | -1;
  expr: Expr; pose: Pose;
  feet?: {L: 'sandal' | 'bare' | 'none'; R: 'sandal' | 'bare' | 'none'};
  /** Senter di tangan: 'R' atau 'L'. */
  flashlight?: 'L' | 'R' | null;
  flashlightOn?: boolean;
  back?: boolean;
  shadow?: number;
  /** Squash & stretch vertikal (1 = normal). */
  sy?: number;
  opacity?: number;
  blur?: number;
  /** Redupkan karakter agar menyatu dengan adegan malam (1 = normal). */
  brightness?: number;
  front?: React.ReactNode;
};

export const MainCharacter: React.FC<CharProps> = ({
  x, y, scale = 1, dir = 1, expr, pose, feet = {L: 'sandal', R: 'sandal'}, flashlight = null, flashlightOn = true,
  back = false, shadow = 1, sy = 1, opacity = 1, blur = 0, brightness = 1, front,
}) => {
  const sx = 1 / Math.sqrt(sy);
  const filters = [blur > 0 ? `blur(${blur}px)` : '', brightness !== 1 ? `brightness(${brightness}) saturate(${0.8 + brightness * 0.2})` : ''].filter(Boolean).join(' ');
  const hipY = pose.hipY;
  return (
    <g transform={`translate(${x},${y}) scale(${dir * scale * sx},${scale * sy})`} opacity={opacity} style={filters ? {filter: filters} : undefined}>
      <defs>
        <radialGradient id="cgHead" cx="38%" cy="32%" r="78%">
          <stop offset="0" stopColor="#FFFFFF" />
          <stop offset="0.65" stopColor="#F5F7FC" />
          <stop offset="1" stopColor="#C9CFE2" />
        </radialGradient>
        <linearGradient id="cgHair" x1="0" y1="0" x2="0.3" y2="1">
          <stop offset="0" stopColor="#6C3C25" />
          <stop offset="1" stopColor="#47241A" />
        </linearGradient>
      </defs>
      <ellipse cx={0} cy={4} rx={118} ry={17} fill="#000" opacity={0.26 * shadow} />
      {/* kaki */}
      <Leg hx={-38} hy={-220 + hipY} a={pose.legL} foot={feet.L} />
      <Leg hx={38} hy={-220 + hipY} a={pose.legR} foot={feet.R} />
      {/* badan, lengan, kepala ikut membungkuk */}
      <g transform={`translate(0,${hipY}) rotate(${pose.lean} 0 -220)`}>
        {back && <ellipse cx={0} cy={-436} rx={104} ry={72} fill={HOOD_SHADE} stroke={INK} strokeWidth={7} />}
        <path d="M -90,-408 Q 0,-434 90,-408 L 114,-224 Q 0,-204 -114,-224 Z" fill={HOOD} stroke={INK} strokeWidth={7} strokeLinejoin="round" />
        <path d="M 40,-414 L 114,-224 Q 80,-212 56,-210 Z" fill={HOOD_SHADE} opacity={0.55} />
        {!back && (
          <g>
            <ellipse cx={0} cy={-410} rx={84} ry={30} fill="#B6BCC9" stroke={INK} strokeWidth={7} />
            <ellipse cx={0} cy={-414} rx={50} ry={16} fill="#7F8795" />
            <path d="M -66,-318 L 66,-318 L 82,-240 L -82,-240 Z" fill="#BEC4CF" stroke="#8C93A0" strokeWidth={5} strokeLinejoin="round" />
            {[[-26, -396, -32, -322], [26, -396, 32, -326]].map(([x1, y1, x2, y2], i) => (
              <g key={i}>
                <line x1={x1} y1={y1} x2={x2} y2={y2} stroke={INK} strokeWidth={12} strokeLinecap="round" />
                <line x1={x1} y1={y1} x2={x2} y2={y2} stroke="#fff" strokeWidth={6} strokeLinecap="round" />
                <circle cx={x2} cy={y2 + 4} r={6} fill="#fff" stroke={INK} strokeWidth={3} />
              </g>
            ))}
          </g>
        )}
        {back && <path d="M -40,-388 Q 0,-340 40,-388" fill="none" stroke="#8C93A0" strokeWidth={5} />}
        <Arm sx={-96} a={pose.armL} light={flashlight === 'L'} lightOn={flashlightOn} />
        <Arm sx={96} a={pose.armR} light={flashlight === 'R'} lightOn={flashlightOn} />
        <g transform={`translate(0,${-545 + pose.headDy}) rotate(${pose.headRot} 0 125)`}>
          <circle r={R} fill="url(#cgHead)" stroke={INK} strokeWidth={8} />
          {!back && <Face e={expr} />}
          <path d={back ? HAIR_BACK : HAIR_FRONT} fill="url(#cgHair)" stroke="#1B0E08" strokeWidth={7} strokeLinejoin="round" />
          {HAIR_LIGHTS.map((d, i) => (
            <path key={i} d={d} stroke="#8B5538" strokeWidth={5} strokeLinecap="round" opacity={0.8} />
          ))}
        </g>
        {front}
      </g>
    </g>
  );
};
