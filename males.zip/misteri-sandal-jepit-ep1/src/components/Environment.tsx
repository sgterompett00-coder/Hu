import React from 'react';
import {HEIGHT, WIDTH} from '../data/beats';
import {hash, mixColor} from '../utils/anim';

export type Pt = [number, number];
export const toward = (p: Pt, vp: Pt, k: number): Pt => [vp[0] + (p[0] - vp[0]) * k, vp[1] + (p[1] - vp[1]) * k];
const poly = (pts: Pt[]): string => pts.map((p) => `${p[0].toFixed(1)},${p[1].toFixed(1)}`).join(' ');
export const INK_E = '#14141A';

/** Satu kanvas SVG penuh 1080x1920; semua gambar lingkungan memakai koordinat panggung. */
export const Stage: React.FC<{children?: React.ReactNode; style?: React.CSSProperties}> = ({children, style}) => (
  <svg width={WIDTH} height={HEIGHT} viewBox={`0 0 ${WIDTH} ${HEIGHT}`} style={{position: 'absolute', left: 0, top: 0, overflow: 'visible', ...style}}>
    {children}
  </svg>
);

/* -------------------------------- PALET -------------------------------- */
export type Pal = {
  sky1: string; sky2: string; wall: string; wallShade: string; roof: string; roofShade: string; trim: string;
  grass: string; grassShade: string; path: string; pathShade: string; leaf: string; leafShade: string; trunk: string;
  fence: string; fenceShade: string; glass: string; door: string; far: string; far2: string;
  floorA: string; floorB: string; roomWall: string; roomWallShade: string; ceil: string; wood: string; woodShade: string; ink: string;
};
export const DAY: Pal = {
  sky1: '#4FA9EE', sky2: '#CDEBFF', wall: '#F1E9D8', wallShade: '#D3C8B0', roof: '#C8602B', roofShade: '#8F3E1B', trim: '#8B7E66',
  grass: '#86BA52', grassShade: '#6B9C3E', path: '#E6D9BE', pathShade: '#CDBF9F', leaf: '#3C9A45', leafShade: '#256B2E', trunk: '#6B4A2E',
  fence: '#C9AA7C', fenceShade: '#A88A5E', glass: '#9FD6EE', door: '#7B4A27', far: '#9DB7A2', far2: '#B7CDBA',
  floorA: '#EBD3AD', floorB: '#DDBE90', roomWall: '#F6E8C8', roomWallShade: '#E0CDA3', ceil: '#FFF6E2', wood: '#B07B4F', woodShade: '#8A5C37', ink: '#1A1A1F',
};
export const NIGHT: Pal = {
  sky1: '#080D2B', sky2: '#2B2566', wall: '#4A5080', wallShade: '#33385E', roof: '#3C2D56', roofShade: '#271D3B', trim: '#2D3150',
  grass: '#1F4A44', grassShade: '#173A38', path: '#4D5578', pathShade: '#3A4162', leaf: '#1E5249', leafShade: '#133B38', trunk: '#2A2230',
  fence: '#4A4466', fenceShade: '#363150', glass: '#F8D987', door: '#4A3040', far: '#1E2650', far2: '#262E5C',
  floorA: '#3F4570', floorB: '#353B63', roomWall: '#434A75', roomWallShade: '#30365A', ceil: '#4A5080', wood: '#3C3550', woodShade: '#2A2540', ink: '#05060F',
};
/** k: 0 = siang, 1 = malam (dusk di antara). */
export const palAt = (k: number): Pal => {
  const o = {} as Pal;
  (Object.keys(DAY) as Array<keyof Pal>).forEach((key) => {
    o[key] = mixColor(DAY[key], NIGHT[key], k);
  });
  return o;
};

/* ------------------------------ GEOMETRI 3D ------------------------------ */
type BoxProps = {
  x: number; y: number; w: number; h: number; k?: number; vp: Pt;
  front: string; top?: string; side?: string; stroke?: string; sw?: number; children?: React.ReactNode;
};
/** Kotak berperspektif satu titik hilang: muka depan + sisi/atas yang terlihat. */
export const Box3D: React.FC<BoxProps> = ({x, y, w, h, k = 0.85, vp, front, top, side, stroke = INK_E, sw = 5, children}) => {
  const A: Pt = [x, y], B: Pt = [x + w, y], C: Pt = [x + w, y + h], D: Pt = [x, y + h];
  const a = toward(A, vp, k), b = toward(B, vp, k), c = toward(C, vp, k), d = toward(D, vp, k);
  const sp = {stroke, strokeWidth: sw, strokeLinejoin: 'round' as const};
  return (
    <g>
      {x + w < vp[0] && <polygon points={poly([B, b, c, C])} fill={side ?? front} {...sp} />}
      {x > vp[0] && <polygon points={poly([A, a, d, D])} fill={side ?? front} {...sp} />}
      {y > vp[1] && <polygon points={poly([A, B, b, a])} fill={top ?? front} {...sp} />}
      <rect x={x} y={y} width={w} height={h} fill={front} {...sp} />
      {children}
    </g>
  );
};

type FloorProps = {vp: Pt; nearY: number; farY: number; x0: number; x1: number; cols: number; rows: number; a: string; b: string; grout?: string; gw?: number};
/** Lantai/jalan berperspektif: baris makin rapat ke cakrawala, kolom menyatu di titik hilang. */
export const PerspFloor: React.FC<FloorProps> = ({vp, nearY, farY, x0, x1, cols, rows, a, b, grout = 'rgba(0,0,0,0.18)', gw = 2}) => {
  const H = vp[1];
  const zMax = (nearY - H) / (farY - H);
  const ys = Array.from({length: rows + 1}, (_, j) => H + (nearY - H) / (1 + (j * (zMax - 1)) / rows));
  const xAt = (xn: number, y: number) => vp[0] + ((xn - vp[0]) * (y - H)) / (nearY - H);
  const tiles: React.ReactNode[] = [];
  for (let j = 0; j < rows; j++) {
    for (let i = 0; i < cols; i++) {
      const xa = x0 + ((x1 - x0) * i) / cols, xb = x0 + ((x1 - x0) * (i + 1)) / cols;
      const pts: Pt[] = [[xAt(xa, ys[j]), ys[j]], [xAt(xb, ys[j]), ys[j]], [xAt(xb, ys[j + 1]), ys[j + 1]], [xAt(xa, ys[j + 1]), ys[j + 1]]];
      tiles.push(<polygon key={`${i}-${j}`} points={poly(pts)} fill={(i + j) % 2 === 0 ? a : b} stroke={grout} strokeWidth={gw} />);
    }
  }
  return <g>{tiles}</g>;
};

type RoomProps = {vp: Pt; near: {x: number; y: number; w: number; h: number}; k: number; pal: Pal; cols?: number; rows?: number; floorA?: string; floorB?: string; wallColor?: string};
/** Ruangan kotak: dinding belakang, dinding samping, langit-langit, lantai ubin/kayu. */
export const Room: React.FC<RoomProps> = ({vp, near, k, pal, cols = 10, rows = 9, floorA, floorB, wallColor}) => {
  const nTL: Pt = [near.x, near.y], nTR: Pt = [near.x + near.w, near.y], nBR: Pt = [near.x + near.w, near.y + near.h], nBL: Pt = [near.x, near.y + near.h];
  const bTL = toward(nTL, vp, k), bTR = toward(nTR, vp, k), bBR = toward(nBR, vp, k), bBL = toward(nBL, vp, k);
  return (
    <g>
      <polygon points={poly([nTL, nTR, bTR, bTL])} fill={pal.ceil} />
      <polygon points={poly([nTL, bTL, bBL, nBL])} fill={pal.roomWallShade} />
      <polygon points={poly([nTR, bTR, bBR, nBR])} fill={mixColor(pal.roomWallShade, '#000000', 0.12)} />
      <rect x={bTL[0]} y={bTL[1]} width={bTR[0] - bTL[0]} height={bBL[1] - bTL[1]} fill={wallColor ?? pal.roomWall} />
      <PerspFloor vp={vp} nearY={nBL[1]} farY={bBL[1]} x0={near.x} x1={near.x + near.w} cols={cols} rows={rows} a={floorA ?? pal.floorA} b={floorB ?? pal.floorB} />
      <rect x={bTL[0]} y={bBL[1] - 16} width={bTR[0] - bTL[0]} height={16} fill={pal.trim} opacity={0.55} />
      <polygon points={poly([bTL, bTR, bBR, bBL])} fill="none" stroke="rgba(0,0,0,0.25)" strokeWidth={4} />
    </g>
  );
};

/* ----------------------------- LANGIT & TANAMAN ----------------------------- */
export const Cloud: React.FC<{x: number; y: number; s?: number; shade?: string; color?: string}> = ({x, y, s = 1, shade = '#E1EFFA', color = '#FFFFFF'}) => (
  <g transform={`translate(${x},${y}) scale(${s})`}>
    <ellipse cx={0} cy={14} rx={96} ry={30} fill={shade} />
    <ellipse cx={0} cy={0} rx={90} ry={32} fill={color} />
    <ellipse cx={-50} cy={-14} rx={50} ry={34} fill={color} />
    <ellipse cx={20} cy={-30} rx={60} ry={40} fill={color} />
    <ellipse cx={72} cy={-8} rx={46} ry={28} fill={color} />
  </g>
);

export const Leaf: React.FC<{x: number; y: number; rot: number; len: number; wid: number; fill: string; shade: string; sway?: number}> = ({x, y, rot, len, wid, fill, shade, sway = 0}) => (
  <g transform={`translate(${x},${y}) rotate(${rot + sway})`}>
    <path d={`M 0,0 C ${wid},${-len * 0.3} ${wid * 0.8},${-len * 0.8} 0,${-len} C ${-wid * 0.8},${-len * 0.8} ${-wid},${-len * 0.3} 0,0 Z`} fill={fill} stroke={INK_E} strokeWidth={4} strokeLinejoin="round" />
    <path d={`M 0,0 C ${wid * 0.5},${-len * 0.3} ${wid * 0.4},${-len * 0.8} 0,${-len} L 0,0 Z`} fill={shade} opacity={0.55} />
    <path d={`M 0,-4 L 0,${-len * 0.92}`} stroke={shade} strokeWidth={4} strokeLinecap="round" />
  </g>
);

/** Semak: kumpulan daun lebar dengan goyangan angin (t = detik). */
export const Bush: React.FC<{x: number; y: number; s?: number; pal: Pal; t?: number; seed?: number; leaves?: number; spread?: number}> = ({x, y, s = 1, pal, t = 0, seed = 1, leaves = 9, spread = 150}) => (
  <g transform={`translate(${x},${y}) scale(${s})`}>
    {Array.from({length: leaves}).map((_, i) => {
      const a = -spread / 2 + (spread * i) / Math.max(1, leaves - 1) + (hash(i + seed) - 0.5) * 14;
      const len = 150 + hash(i * 3 + seed) * 90;
      return (
        <Leaf key={i} x={(hash(i + seed * 2) - 0.5) * 60} y={0} rot={a} len={len} wid={46 + hash(i + 5) * 22}
          fill={i % 2 ? pal.leaf : mixColor(pal.leaf, '#ffffff', 0.08)} shade={pal.leafShade} sway={Math.sin(t * 1.6 + i * 1.3 + seed) * 2.4} />
      );
    })}
  </g>
);

export const Tree: React.FC<{x: number; y: number; s?: number; pal: Pal; t?: number}> = ({x, y, s = 1, pal, t = 0}) => (
  <g transform={`translate(${x},${y}) scale(${s})`}>
    <path d="M -22,0 L -14,-300 L 14,-300 L 24,0 Z" fill={pal.trunk} stroke={INK_E} strokeWidth={6} strokeLinejoin="round" />
    {[[-110, -330, 110], [0, -420, 130], [110, -330, 105], [-40, -330, 100], [60, -380, 90]].map(([cx, cy, r], i) => (
      <g key={i} transform={`translate(${Math.sin(t * 0.9 + i) * 2.5},0)`}>
        <circle cx={cx} cy={cy} r={r} fill={i % 2 ? pal.leaf : mixColor(pal.leaf, '#ffffff', 0.07)} stroke={INK_E} strokeWidth={6} />
        <path d={`M ${cx - r * 0.7},${cy + r * 0.3} Q ${cx},${cy + r * 1.05} ${cx + r * 0.8},${cy + r * 0.2}`} fill="none" stroke={pal.leafShade} strokeWidth={14} opacity={0.5} strokeLinecap="round" />
      </g>
    ))}
  </g>
);

/** Pagar yang menyusut ke titik hilang. */
export const FenceLine: React.FC<{from: Pt; vp: Pt; n?: number; h0?: number; pal: Pal; r?: number}> = ({from, vp, n = 9, h0 = 220, pal, r = 0.76}) => {
  const posts: Array<{p: Pt; s: number}> = [];
  let s = 1;
  for (let i = 0; i < n; i++) {
    posts.push({p: toward(from, vp, s), s});
    s *= r;
  }
  const top = posts.map(({p, s: ss}) => `${p[0]},${p[1] - h0 * ss}`).join(' ');
  const mid = posts.map(({p, s: ss}) => `${p[0]},${p[1] - h0 * ss * 0.45}`).join(' ');
  return (
    <g>
      <polyline points={top} fill="none" stroke={pal.fenceShade} strokeWidth={14} strokeLinejoin="round" />
      <polyline points={mid} fill="none" stroke={pal.fenceShade} strokeWidth={12} strokeLinejoin="round" />
      {posts.map(({p, s: ss}, i) => (
        <rect key={i} x={p[0] - 20 * ss} y={p[1] - h0 * ss} width={40 * ss} height={h0 * ss} fill={pal.fence} stroke={INK_E} strokeWidth={Math.max(2, 5 * ss)} />
      ))}
    </g>
  );
};

/* ------------------------------ LINGKUNGAN LUAR ------------------------------ */
export const VP_EXT: Pt = [262, 820];

export const ExtSky: React.FC<{k: number; t: number}> = ({k, t}) => {
  const pal = palAt(k);
  return (
    <Stage>
      <defs>
        <linearGradient id="skyG" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor={pal.sky1} />
          <stop offset="1" stopColor={pal.sky2} />
        </linearGradient>
        <radialGradient id="sunG">
          <stop offset="0" stopColor="#FFF6C9" stopOpacity={0.95} />
          <stop offset="1" stopColor="#FFF6C9" stopOpacity={0} />
        </radialGradient>
        <radialGradient id="moonG">
          <stop offset="0" stopColor="#DDE6FF" stopOpacity={0.55} />
          <stop offset="1" stopColor="#DDE6FF" stopOpacity={0} />
        </radialGradient>
      </defs>
      <rect x={-700} y={-700} width={2480} height={1750} fill="url(#skyG)" />
      <g opacity={1 - k}>
        <circle cx={840} cy={250} r={300} fill="url(#sunG)" />
        <circle cx={840} cy={250} r={70} fill="#FFF3B0" />
        {[[120, 330, 1.2], [560, 190, 0.9], [980, 430, 1.0], [300, 520, 0.7]].map(([bx, by, sc], i) => (
          <Cloud key={i} x={((bx + t * (6 + i * 2) + 300) % 1700) - 300} y={by} s={sc} />
        ))}
      </g>
      <g opacity={k}>
        {Array.from({length: 46}).map((_, i) => (
          <circle key={i} cx={hash(i) * 1200 - 60} cy={hash(i + 90) * 640} r={1.5 + hash(i + 5) * 2.5} fill="#fff" opacity={0.55 + 0.45 * Math.sin(t * 2 + i * 1.7)} />
        ))}
        <circle cx={850} cy={290} r={240} fill="url(#moonG)" />
        <path d="M 850,225 A 66 66 0 1 0 850,355 A 52 52 0 1 1 850,225 Z" fill="#FFF4C8" stroke="#FFFBE3" strokeWidth={2} />
      </g>
    </Stage>
  );
};

export const ExtFar: React.FC<{k: number}> = ({k}) => {
  const pal = palAt(k);
  const houses: Array<[number, number, number, number]> = [[-60, 150, 120, 0], [90, 130, 90, 1], [640, 170, 130, 1], [800, 150, 100, 0], [940, 160, 140, 1], [1090, 140, 100, 0]];
  return (
    <Stage>
      <rect x={-700} y={760} width={2480} height={90} fill={pal.far2} />
      {houses.map(([x, w, h, v], i) => (
        <g key={i}>
          <rect x={x} y={830 - h} width={w} height={h} fill={v ? pal.far : pal.far2} />
          <polygon points={`${x - 8},${830 - h} ${x + w + 8},${830 - h} ${x + w / 2},${830 - h - 50}`} fill={pal.roofShade} opacity={0.75} />
          <rect x={x + w * 0.25} y={830 - h * 0.62} width={w * 0.2} height={h * 0.22} fill={pal.glass} opacity={0.7 + 0.3 * k} />
        </g>
      ))}
      {[[20, 110], [740, 120], [1030, 100]].map(([x, r], i) => (
        <circle key={i} cx={x} cy={800} r={r * 0.6} fill={pal.leaf} opacity={0.55} />
      ))}
    </Stage>
  );
};

export const ExtGround: React.FC<{k: number}> = ({k}) => {
  const pal = palAt(k);
  return (
    <Stage>
      <rect x={-700} y={820} width={2480} height={1500} fill={pal.grass} />
      {Array.from({length: 7}).map((_, i) => (
        <rect key={i} x={-700} y={850 + i * i * 22} width={2480} height={10 + i * 4} fill={pal.grassShade} opacity={0.35} />
      ))}
      <PerspFloor vp={VP_EXT} nearY={1920} farY={1010} x0={192} x1={888} cols={4} rows={13} a={pal.path} b={mixColor(pal.path, pal.pathShade, 0.55)} grout={mixColor(pal.pathShade, '#000000', 0.25)} gw={3} />
    </Stage>
  );
};

type HouseProps = {k: number; t: number; doorOpen?: number; lit?: number};
/** Rumah depan (satu rumah yang sama di siang & malam). */
export const ExtHouse: React.FC<HouseProps> = ({k, t, doorOpen = 0, lit = 0}) => {
  const pal = palAt(k);
  const th = (doorOpen * 68 * Math.PI) / 180;
  const dw = 120 * Math.cos(th);
  const win = (x: number) => (
    <g>
      <rect x={x - 8} y={642} width={136} height={158} fill={pal.trim} stroke={INK_E} strokeWidth={5} />
      <rect x={x} y={650} width={120} height={134} fill={pal.glass} stroke={INK_E} strokeWidth={4} />
      <path d={`M ${x},${650} L ${x + 120},${650} L ${x + 120},${700} Z`} fill="#fff" opacity={0.28} />
      <line x1={x + 60} y1={650} x2={x + 60} y2={784} stroke={INK_E} strokeWidth={5} />
      <line x1={x} y1={716} x2={x + 120} y2={716} stroke={INK_E} strokeWidth={5} />
      <rect x={x - 14} y={800} width={148} height={14} fill={pal.wallShade} stroke={INK_E} strokeWidth={4} />
    </g>
  );
  return (
    <Stage>
      <defs>
        <radialGradient id="lampG">
          <stop offset="0" stopColor="#FFE9A0" stopOpacity={0.95} />
          <stop offset="1" stopColor="#FFE9A0" stopOpacity={0} />
        </radialGradient>
        <linearGradient id="doorLightG" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#FFE7A0" stopOpacity={0.85} />
          <stop offset="1" stopColor="#FFE7A0" stopOpacity={0} />
        </linearGradient>
      </defs>
      {/* tetangga kanan (perspektif) */}
      <Box3D x={800} y={690} w={300} h={320} k={0.7} vp={VP_EXT} front={mixColor(pal.wall, pal.wallShade, 0.3)} side={pal.wallShade} top={pal.roofShade}>
        <rect x={840} y={760} width={90} height={110} fill={pal.glass} stroke={INK_E} strokeWidth={4} />
        <polygon points="780,690 1120,690 1040,600 860,600" fill={pal.roof} stroke={INK_E} strokeWidth={5} strokeLinejoin="round" />
      </Box3D>
      <Tree x={20} y={1010} s={1.1} pal={pal} t={t} />
      {/* atap */}
      <polygon points="24,552 596,552 500,392 120,392" fill={pal.roof} stroke={INK_E} strokeWidth={6} strokeLinejoin="round" />
      {[430, 470, 510].map((y) => (
        <line key={y} x1={24 + (552 - y) * 0.6} y1={y} x2={596 - (552 - y) * 0.6} y2={y} stroke={pal.roofShade} strokeWidth={5} opacity={0.7} />
      ))}
      <rect x={30} y={544} width={560} height={20} fill={pal.roofShade} stroke={INK_E} strokeWidth={5} />
      {/* dinding */}
      <rect x={60} y={564} width={500} height={446} fill={pal.wall} stroke={INK_E} strokeWidth={6} />
      <rect x={60} y={564} width={500} height={34} fill="#000" opacity={0.08} />
      <rect x={60} y={960} width={500} height={50} fill={pal.wallShade} />
      {win(100)}
      {win(400)}
      {/* pintu */}
      <rect x={236} y={752} width={148} height={258} fill={pal.trim} stroke={INK_E} strokeWidth={5} />
      <rect x={250} y={766} width={120} height={244} fill={mixColor('#2A1A12', '#FFD98A', Math.max(0, doorOpen * (0.25 + 0.55 * (1 - k * 0.2))))} />
      <polygon points={`250,766 ${250 + dw},${766 - 10 * Math.sin(th)} ${250 + dw},${1010 + 8 * Math.sin(th)} 250,1010`} fill={pal.door} stroke={INK_E} strokeWidth={5} strokeLinejoin="round" />
      <rect x={256 + dw * 0.18} y={800} width={Math.max(2, dw * 0.58)} height={80} fill="#000" opacity={0.14} />
      <circle cx={250 + dw - 12} cy={900} r={7} fill="#E2C15A" stroke={INK_E} strokeWidth={3} />
      {/* teras & lampu */}
      <rect x={210} y={1010} width={200} height={26} fill={pal.pathShade} stroke={INK_E} strokeWidth={5} />
      <rect x={300} y={716} width={20} height={26} fill={pal.trim} stroke={INK_E} strokeWidth={3} />
      <circle cx={310} cy={712} r={11} fill="#FFE9A0" stroke={INK_E} strokeWidth={3} />
      <circle cx={310} cy={712} r={120} fill="url(#lampG)" opacity={k * 0.9} />
      {/* cahaya dari pintu terbuka */}
      {doorOpen > 0.05 && (
        <polygon points={`250,1010 370,1010 ${470 + 140 * (1 - k)},1230 ${150 - 140 * (1 - k)},1230`} fill="url(#doorLightG)" opacity={lit * doorOpen} style={{mixBlendMode: 'screen'}} />
      )}
      {/* semak depan */}
      {[[96, 1010, 0.7], [182, 1016, 0.55], [452, 1012, 0.6], [528, 1010, 0.7]].map(([bx, by, bs], i) => (
        <Bush key={i} x={bx} y={by} s={bs} pal={pal} t={t} seed={i + 1} leaves={7} spread={120} />
      ))}
      <FenceLine from={[1180, 1500]} vp={VP_EXT} n={10} h0={210} pal={pal} />
    </Stage>
  );
};
