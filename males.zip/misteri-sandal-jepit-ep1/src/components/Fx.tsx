import React from 'react';
import {HEIGHT, WIDTH} from '../data/beats';
import {hash} from '../utils/anim';
import {INK} from './MainCharacter';

/** Vignette gelap di pinggir layar. */
export const Vignette: React.FC<{strength?: number; color?: string}> = ({strength = 0.5, color = '0,0,0'}) => (
  <div
    style={{
      position: 'absolute', left: 0, top: 0, width: WIDTH, height: HEIGHT, pointerEvents: 'none',
      background: `radial-gradient(ellipse at 50% 46%, rgba(${color},0) 42%, rgba(${color},${strength}) 100%)`,
    }}
  />
);

/** Lapisan warna layar penuh (grading). */
export const Tint: React.FC<{color: string; opacity: number; blend?: React.CSSProperties['mixBlendMode']}> = ({color, opacity, blend = 'normal'}) => (
  <div style={{position: 'absolute', left: 0, top: 0, width: WIDTH, height: HEIGHT, background: color, opacity, mixBlendMode: blend, pointerEvents: 'none'}} />
);

/** Garis kecepatan radial (Panel 6, 8, 9). Deterministik. */
export const SpeedLines: React.FC<{
  cx?: number; cy?: number; count?: number; inner?: number; outer?: number; color?: string; opacity?: number; seed?: number; frame?: number; width?: number;
}> = ({cx = 540, cy = 960, count = 46, inner = 480, outer = 1500, color = '#fff', opacity = 0.7, seed = 1, frame = 0, width = 7}) => {
  const polys: string[] = [];
  for (let i = 0; i < count; i++) {
    const a = (i / count) * Math.PI * 2 + hash(i + seed) * 0.12;
    const jitter = hash(i * 3 + seed + Math.floor(frame / 2)) * 90;
    const r0 = inner + hash(i + seed * 7) * 220 + jitter;
    const r1 = outer;
    const w = (width * (0.4 + hash(i + 40 + seed))) / 2;
    const ca = Math.cos(a), sa = Math.sin(a);
    const nx = -sa, ny = ca;
    polys.push(`${cx + ca * r0 + nx * w * 0.2},${cy + sa * r0 + ny * w * 0.2} ${cx + ca * r1 + nx * w * 6},${cy + sa * r1 + ny * w * 6} ${cx + ca * r1 - nx * w * 6},${cy + sa * r1 - ny * w * 6} ${cx + ca * r0 - nx * w * 0.2},${cy + sa * r0 - ny * w * 0.2}`);
  }
  return (
    <svg width={WIDTH} height={HEIGHT} viewBox={`0 0 ${WIDTH} ${HEIGHT}`} style={{position: 'absolute', left: 0, top: 0, pointerEvents: 'none'}} opacity={opacity}>
      {polys.map((p, i) => <polygon key={i} points={p} fill={color} />)}
    </svg>
  );
};

/** Tiga garis kuning "kejut" seperti di storyboard. */
export const ImpactLines: React.FC<{x: number; y: number; rot?: number; scale?: number; t?: number; start?: number; color?: string}> = ({
  x, y, rot = 0, scale = 1, t = 99, start = 0, color = '#FFC928',
}) => {
  const k = Math.min(1, Math.max(0, (t - start) / 0.16));
  if (k <= 0) return null;
  const over = k < 1 ? k : 1;
  return (
    <g transform={`translate(${x},${y}) rotate(${rot}) scale(${scale * over})`}>
      <polygon points="-10,0 40,-70 55,-62" fill={color} stroke={INK} strokeWidth={4} strokeLinejoin="round" />
      <polygon points="20,40 100,-4 108,12" fill={color} stroke={INK} strokeWidth={4} strokeLinejoin="round" />
      <polygon points="30,86 90,70 88,88" fill={color} stroke={INK} strokeWidth={4} strokeLinejoin="round" />
    </g>
  );
};

/** Tanda seru merah ganda (Panel 9). */
export const Exclaim: React.FC<{x: number; y: number; scale?: number; rot?: number}> = ({x, y, scale = 1, rot = 8}) => {
  const bang = (dx: number, s: number) => (
    <g transform={`translate(${dx},0) scale(${s})`}>
      <polygon points="-22,-120 22,-120 12,26 -12,26" fill="#E5201F" stroke="#fff" strokeWidth={10} strokeLinejoin="round" />
      <polygon points="-22,-120 22,-120 12,26 -12,26" fill="#E5201F" />
      <circle cx={0} cy={66} r={17} fill="#E5201F" stroke="#fff" strokeWidth={8} />
      <circle cx={0} cy={66} r={17} fill="#E5201F" />
    </g>
  );
  return (
    <g transform={`translate(${x},${y}) rotate(${rot}) scale(${scale})`}>
      {bang(-34, 1)}
      {bang(34, 1)}
    </g>
  );
};

/** Tanda tanya komedi di atas kepala. */
export const QMark: React.FC<{x: number; y: number; scale?: number; rot?: number}> = ({x, y, scale = 1, rot = 0}) => (
  <g transform={`translate(${x},${y}) rotate(${rot}) scale(${scale})`}>
    <path d="M -34,-40 C -34,-92 40,-92 40,-44 C 40,-14 6,-12 6,22" fill="none" stroke={INK} strokeWidth={30} strokeLinecap="round" />
    <path d="M -34,-40 C -34,-92 40,-92 40,-44 C 40,-14 6,-12 6,22" fill="none" stroke="#FFD93B" strokeWidth={16} strokeLinecap="round" />
    <circle cx={6} cy={64} r={15} fill="#FFD93B" stroke={INK} strokeWidth={6} />
  </g>
);

/** Berkas cahaya senter (kerucut). angle: 0 = +x, 90 = bawah. */
export const Beam: React.FC<{
  x: number; y: number; angle: number; len?: number; spread?: number; intensity?: number; color?: string; id?: string; flicker?: number;
}> = ({x, y, angle, len = 900, spread = 26, intensity = 0.8, color = '#FFF1A8', id = 'beamG', flicker = 0}) => {
  const half = (len * Math.tan((spread * Math.PI) / 360));
  return (
    <g transform={`translate(${x},${y}) rotate(${angle})`} style={{mixBlendMode: 'screen'}} opacity={Math.max(0, intensity * (1 - flicker))}>
      <defs>
        <linearGradient id={id} x1="0" y1="0" x2="1" y2="0">
          <stop offset="0" stopColor={color} stopOpacity={0.95} />
          <stop offset="0.55" stopColor={color} stopOpacity={0.38} />
          <stop offset="1" stopColor={color} stopOpacity={0.05} />
        </linearGradient>
      </defs>
      <polygon points={`0,-6 ${len},${-half} ${len},${half} 0,6`} fill={`url(#${id})`} />
    </g>
  );
};

/** Kolam cahaya di tanah. */
export const Pool: React.FC<{x: number; y: number; rx: number; ry: number; intensity?: number; color?: string; id?: string}> = ({
  x, y, rx, ry, intensity = 0.7, color = '#FFF1A8', id = 'poolG',
}) => (
  <g style={{mixBlendMode: 'screen'}} opacity={intensity}>
    <defs>
      <radialGradient id={id}>
        <stop offset="0" stopColor={color} stopOpacity={0.9} />
        <stop offset="0.6" stopColor={color} stopOpacity={0.35} />
        <stop offset="1" stopColor={color} stopOpacity={0} />
      </radialGradient>
    </defs>
    <ellipse cx={x} cy={y} rx={rx} ry={ry} fill={`url(#${id})`} />
  </g>
);

/** Partikel melayang (debu / serangga malam). Deterministik. */
export const Dust: React.FC<{
  count?: number; t: number; x?: number; y?: number; w?: number; h?: number; color?: string; size?: number; seed?: number; speed?: number; opacity?: number;
}> = ({count = 24, t, x = 0, y = 0, w = WIDTH, h = HEIGHT, color = '#fff', size = 5, seed = 3, speed = 1, opacity = 0.6}) => (
  <g opacity={opacity}>
    {Array.from({length: count}).map((_, i) => {
      const bx = x + hash(i + seed) * w;
      const by = y + hash(i * 5 + seed) * h;
      const px = bx + Math.sin(t * speed * (0.6 + hash(i) * 0.8) + i) * 26;
      const py = by + Math.cos(t * speed * (0.5 + hash(i + 9) * 0.7) + i * 2) * 22 - ((t * speed * 8 * hash(i + 3)) % 40);
      return <circle key={i} cx={px} cy={py} r={size * (0.4 + hash(i + 11))} fill={color} />;
    })}
  </g>
);
