import React from 'react';
import {spring, useCurrentFrame, useVideoConfig} from 'remotion';
import {AUDIO_OFFSET} from '../data/beats';
import {PHRASES} from '../data/captions';
import {LAYOUT} from '../data/layout';
import {clamp} from '../utils/anim';

const FONT = "'Poppins', 'Montserrat', 'Arial Black', 'Segoe UI Black', Impact, sans-serif";

/**
 * Subtitle frasa pendek (maks 2 baris), putih + outline hitam, kata penting kuning.
 * Dipasang di level root (frame global). Tidak ada header/judul lain di video.
 */
export const Subtitle: React.FC = () => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const t = frame / fps - AUDIO_OFFSET;
  const ph = PHRASES.find((p) => t >= p.start - 0.04 && t < p.end);
  if (!ph) return null;
  const local = Math.max(0, (t - ph.start) * fps + 1);
  const s = spring({frame: local, fps, config: {damping: 11, stiffness: 220, mass: 0.55}});
  const scale = 0.82 + 0.18 * s;
  const opacity = clamp(local / 3);
  const box = LAYOUT.subtitle;
  return (
    <div
      style={{
        position: 'absolute', left: box.x, top: box.y, width: box.w, height: box.h,
        display: 'flex', alignItems: 'flex-start', justifyContent: 'center', pointerEvents: 'none',
      }}
    >
      <div
        style={{
          transform: `scale(${scale})`, opacity, transformOrigin: '50% 30%', textAlign: 'center',
          fontFamily: FONT, fontWeight: 900, fontSize: 58, lineHeight: 1.16, letterSpacing: 0.5,
          color: '#fff', WebkitTextStroke: '11px #000', paintOrder: 'stroke fill',
          textShadow: '0 6px 0 rgba(0,0,0,0.55)', maxWidth: box.w,
        }}
      >
        {ph.words.map((w, i) => (
          <span key={i} style={{color: w.keyword ? '#FFD93B' : '#fff'}}>
            {w.text}
            {i < ph.words.length - 1 ? ' ' : ''}
          </span>
        ))}
      </div>
    </div>
  );
};
