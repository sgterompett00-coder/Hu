import React from 'react';
import {Box3D, INK_E, Leaf, Pal, Pt, toward} from './Environment';
import {SANDAL, SOLE_PATH, Sandal} from './Sandal';
import {hash, mixColor} from '../utils/anim';

/* ---------------------------------- JEJAK ---------------------------------- */
/** Jejak sandal jepit: bentuk sol + alur tali Y (sama dengan sandal master). */
export const Footprint: React.FC<{x: number; y: number; rot?: number; scale?: number; tilt?: number; opacity?: number; dirt?: string; rim?: string}> = ({
  x, y, rot = 0, scale = 1, tilt = 1, opacity = 1, dirt = '#3B2A20', rim = '#8A6A50',
}) => (
  <g transform={`translate(${x},${y}) scale(1,${tilt}) rotate(${rot}) scale(${scale})`} opacity={opacity}>
    <path d={SOLE_PATH} fill={rim} transform="scale(1.1)" opacity={0.55} />
    <path d={SOLE_PATH} fill={dirt} stroke="#1E140E" strokeWidth={5} strokeLinejoin="round" />
    <path d="M -33,-6 Q -14,-30 0,-56 Q 14,-30 33,-6" fill="none" stroke={rim} strokeWidth={11} strokeLinecap="round" opacity={0.85} />
    <circle cx={0} cy={-56} r={8} fill={rim} opacity={0.85} />
    <path d={SOLE_PATH} transform="scale(0.84)" fill="none" stroke="#5B4332" strokeWidth={4} opacity={0.7} />
  </g>
);

/** Tumpukan sandal sebelah (Beat 3). */
export const SandalPile: React.FC<{x: number; y: number; n: number; scale?: number}> = ({x, y, n, scale = 1}) => (
  <g transform={`translate(${x},${y}) scale(${scale})`}>
    {Array.from({length: n}).map((_, i) => {
      const row = Math.floor(i / 3);
      const col = i % 3;
      return <Sandal key={i} x={(col - 1) * 110 + (hash(i + 4) - 0.5) * 36 + (row % 2) * 30} y={-row * 52 + (hash(i) - 0.5) * 14} rot={(hash(i + 8) - 0.5) * 120} tilt={0.62} scale={0.82} thick={10} />;
    })}
  </g>
);

/* ---------------------------------- KALENDER ---------------------------------- */
export const Calendar: React.FC<{x: number; y: number; w?: number; h?: number; rot?: number; scale?: number; circle?: number; banner?: number; day?: number}> = ({
  x, y, w = 420, h = 330, rot = -5, scale = 1, circle = 1, banner = 1, day = 0,
}) => {
  const hd = h * 0.2;
  const cw = (w - 36) / 7, ch = (h - hd - 30) / 5;
  const cc = 4 + (day % 3), cr = 2 + (day % 2);
  const circ = 2 * Math.PI * 30;
  return (
    <g transform={`translate(${x},${y}) rotate(${rot}) scale(${scale})`}>
      <rect x={8} y={12} width={w} height={h} fill="#000" opacity={0.22} />
      <rect width={w} height={h} fill="#FFFDF7" stroke={INK_E} strokeWidth={5} />
      <rect width={w} height={hd} fill="#D9352B" stroke={INK_E} strokeWidth={5} />
      {[0.25, 0.75].map((f, i) => <rect key={i} x={w * f - 8} y={-14} width={16} height={34} rx={8} fill="#555" stroke={INK_E} strokeWidth={3} />)}
      {Array.from({length: 5}).map((_, r) =>
        Array.from({length: 7}).map((__, c) => (
          <g key={`${r}${c}`}>
            <rect x={18 + c * cw} y={hd + 14 + r * ch} width={cw - 4} height={ch - 4} fill="none" stroke="#C9C3B5" strokeWidth={2} />
            <text x={18 + c * cw + 6} y={hd + 14 + r * ch + 20} fontSize={15} fontFamily="Arial, sans-serif" fontWeight={700} fill="#777">{r * 7 + c + 1}</text>
          </g>
        )),
      )}
      <ellipse cx={18 + cc * cw + cw / 2 - 2} cy={hd + 14 + cr * ch + ch / 2 - 2} rx={cw * 0.55} ry={ch * 0.55} fill="none" stroke="#E01F1F" strokeWidth={7}
        strokeDasharray={`${circ * 1.2} ${circ * 1.2}`} strokeDashoffset={(1 - circle) * circ * 1.2} strokeLinecap="round" transform={`rotate(-8 ${18 + cc * cw + cw / 2} ${hd + 14 + cr * ch + ch / 2})`} />
      {banner > 0 && (
        <g transform={`translate(-34,-50) rotate(-4) scale(${banner})`}>
          <rect x={0} y={0} width={w * 0.78} height={64} fill="#fff" stroke={INK_E} strokeWidth={5} />
          <text x={w * 0.39} y={46} textAnchor="middle" fontSize={44} fontFamily="'Poppins','Arial Black',Impact,sans-serif" fontWeight={900} fontStyle="italic" fill="#D9201F">Besoknya...</text>
        </g>
      )}
    </g>
  );
};

/* ------------------------------ FURNITUR RUANGAN ------------------------------ */
export const WindowRoom: React.FC<{x: number; y: number; w: number; h: number; pal: Pal}> = ({x, y, w, h, pal}) => (
  <g>
    <rect x={x - 10} y={y - 10} width={w + 20} height={h + 20} fill={pal.trim} stroke={INK_E} strokeWidth={5} />
    <rect x={x} y={y} width={w} height={h} fill="#9AD3F2" stroke={INK_E} strokeWidth={4} />
    <polygon points={`${x},${y} ${x + w * 0.6},${y} ${x},${y + h * 0.55}`} fill="#fff" opacity={0.3} />
    <line x1={x + w / 2} y1={y} x2={x + w / 2} y2={y + h} stroke={INK_E} strokeWidth={5} />
    <line x1={x} y1={y + h / 2} x2={x + w} y2={y + h / 2} stroke={INK_E} strokeWidth={5} />
    <path d={`M ${x - 14},${y - 14} L ${x + w * 0.28},${y - 14} Q ${x + w * 0.12},${y + h * 0.5} ${x + w * 0.22},${y + h + 10} L ${x - 14},${y + h + 10} Z`} fill="#F1A64B" stroke={INK_E} strokeWidth={4} opacity={0.95} />
  </g>
);

export const Bookshelf: React.FC<{x: number; y: number; w: number; h: number; pal: Pal}> = ({x, y, w, h, pal}) => {
  const rows = 4;
  const rh = h / rows;
  const cols = ['#D9534F', '#4F8FD9', '#E6B73C', '#5BAA6A', '#8E6BC9', '#E48A3E', '#3E8E8C'];
  return (
    <g>
      <rect x={x} y={y} width={w} height={h} fill={pal.woodShade} stroke={INK_E} strokeWidth={5} />
      {Array.from({length: rows}).map((_, r) => {
        const by = y + (r + 1) * rh - 8;
        let cx = x + 12;
        const books: React.ReactNode[] = [];
        let i = 0;
        while (cx < x + w - 26) {
          const bw = 16 + hash(r * 17 + i) * 14;
          const bh = rh * (0.5 + hash(r * 9 + i + 2) * 0.35);
          if (hash(r * 5 + i + 33) > 0.18) books.push(<rect key={i} x={cx} y={by - bh} width={bw} height={bh} fill={cols[(r * 3 + i) % cols.length]} stroke={INK_E} strokeWidth={3} />);
          cx += bw + 3;
          i++;
        }
        return (
          <g key={r}>
            {books}
            <rect x={x} y={by} width={w} height={10} fill={pal.wood} stroke={INK_E} strokeWidth={3} />
          </g>
        );
      })}
    </g>
  );
};

export const Bed: React.FC<{x: number; y: number; w: number; h: number; vp: Pt; pal: Pal; lift?: number}> = ({x, y, w, h, vp, pal, lift = 0}) => {
  const my = y + h * 0.3;
  return (
    <g>
      <Box3D x={x} y={y + h * 0.5} w={w} h={h * 0.5} k={0.88} vp={vp} front={pal.woodShade} top={pal.wood} side={pal.woodShade} />
      <g transform={`translate(0,${-lift * 70}) rotate(${-lift * 7} ${x + w} ${y + h * 0.5})`}>
        <Box3D x={x + 8} y={my} w={w - 16} h={h * 0.24} k={0.9} vp={vp} front="#F4EFE6" top="#FBF8F1" side="#DCD5C7" />
        <path d={`M ${x + w * 0.22},${my - 6} L ${x + w - 8},${my - 6} L ${x + w - 8},${my + h * 0.42} L ${x + w * 0.22},${my + h * 0.33} Z`} fill="#2F6BD1" stroke={INK_E} strokeWidth={5} strokeLinejoin="round" />
        <path d={`M ${x + w * 0.3},${my + h * 0.06} L ${x + w - 8},${my + h * 0.06} M ${x + w * 0.4},${my + h * 0.2} L ${x + w - 8},${my + h * 0.24}`} stroke="#1F4FA8" strokeWidth={6} fill="none" opacity={0.7} />
        <rect x={x + 26} y={my - h * 0.14} width={Math.min(190, w * 0.3)} height={h * 0.16} rx={26} fill="#fff" stroke={INK_E} strokeWidth={5} />
      </g>
    </g>
  );
};

export const Wardrobe: React.FC<{x: number; y: number; w: number; h: number; vp: Pt; pal: Pal; open?: number}> = ({x, y, w, h, vp, pal, open = 0}) => {
  const th = (open * 76 * Math.PI) / 180;
  const dw = (w / 2) * Math.cos(th);
  return (
    <g>
      <Box3D x={x} y={y} w={w} h={h} k={0.9} vp={vp} front={pal.wood} top={pal.woodShade} side={pal.woodShade}>
        <rect x={x + 12} y={y + 12} width={w - 24} height={h - 24} fill={open > 0.02 ? '#2E211B' : pal.wood} />
        {open > 0.02 && (
          <g>
            <line x1={x + 16} y1={y + 70} x2={x + w - 16} y2={y + 70} stroke="#8D8D95" strokeWidth={7} />
            {['#D9534F', '#4F8FD9', '#E6B73C', '#5BAA6A', '#E8E8EE'].map((c, i) => (
              <path key={i} d={`M ${x + 40 + i * ((w - 80) / 4.4)},${y + 74} l 26,0 l 14,${h * 0.34} l -52,0 Z`} fill={c} stroke={INK_E} strokeWidth={3} />
            ))}
            <rect x={x + 16} y={y + h * 0.62} width={w - 32} height={10} fill={pal.woodShade} />
          </g>
        )}
        <line x1={x + w / 2} y1={y + 12} x2={x + w / 2} y2={y + h - 12} stroke={INK_E} strokeWidth={5} />
        <polygon points={`${x + 12},${y + 12} ${x + 12 + dw},${y + 12 - 14 * Math.sin(th)} ${x + 12 + dw},${y + h - 12 + 14 * Math.sin(th)} ${x + 12},${y + h - 12}`} fill={pal.wood} stroke={INK_E} strokeWidth={5} strokeLinejoin="round" />
        <rect x={x + w / 2 + 8} y={y + 12} width={w / 2 - 20} height={h - 24} fill={pal.wood} stroke={INK_E} strokeWidth={4} />
        <circle cx={x + w / 2 + 26} cy={y + h * 0.5} r={7} fill="#E2C15A" stroke={INK_E} strokeWidth={3} />
      </Box3D>
    </g>
  );
};

export const Fridge: React.FC<{x: number; y: number; w: number; h: number; vp: Pt; open?: number}> = ({x, y, w, h, vp, open = 0}) => {
  const th = (open * 78 * Math.PI) / 180;
  const dw = (w - 20) * Math.cos(th);
  return (
    <g>
      <Box3D x={x} y={y} w={w} h={h} k={0.9} vp={vp} front="#E6EDF3" top="#F5F9FC" side="#C4CFD9">
        <rect x={x + 10} y={y + h * 0.34} width={w - 20} height={h * 0.64} fill={open > 0.02 ? '#FFFBE8' : '#E6EDF3'} />
        {open > 0.02 && (
          <g>
            {[0.46, 0.6, 0.76].map((f, i) => <rect key={i} x={x + 14} y={y + h * f} width={w - 28} height={7} fill="#9DB4C4" />)}
            <rect x={x + 30} y={y + h * 0.46 - 52} width={34} height={52} fill="#F28B30" stroke={INK_E} strokeWidth={3} />
            <ellipse cx={x + 110} cy={y + h * 0.6 - 18} rx={26} ry={18} fill="#fff" stroke={INK_E} strokeWidth={3} />
            <rect x={x + w - 80} y={y + h * 0.6 - 56} width={30} height={56} fill="#4BA85E" stroke={INK_E} strokeWidth={3} />
            <circle cx={x + 90} cy={y + h * 0.76 - 22} r={22} fill="#D9534F" stroke={INK_E} strokeWidth={3} />
          </g>
        )}
        <line x1={x} y1={y + h * 0.33} x2={x + w} y2={y + h * 0.33} stroke={INK_E} strokeWidth={5} />
        <polygon points={`${x + w - 10},${y + h * 0.34} ${x + w - 10 - dw},${y + h * 0.34 - 18 * Math.sin(th)} ${x + w - 10 - dw},${y + h - 8 + 22 * Math.sin(th)} ${x + w - 10},${y + h - 8}`} fill="#EEF3F7" stroke={INK_E} strokeWidth={5} strokeLinejoin="round" />
        <rect x={x + 14} y={y + h * 0.1} width={10} height={h * 0.18} rx={5} fill="#8A97A3" stroke={INK_E} strokeWidth={3} />
        {open <= 0.02 && <rect x={x + 14} y={y + h * 0.42} width={10} height={h * 0.26} rx={5} fill="#8A97A3" stroke={INK_E} strokeWidth={3} />}
      </Box3D>
    </g>
  );
};

export const Sofa: React.FC<{x: number; y: number; w: number; vp: Pt; cushionLift?: number}> = ({x, y, w, vp, cushionLift = 0}) => (
  <g>
    <Box3D x={x} y={y} w={w} h={150} k={0.92} vp={vp} front="#C9784B" top="#DC8F62" side="#A85F38" />
    <Box3D x={x + 34} y={y + 150 - cushionLift * 30} w={w - 68} h={64} k={0.92} vp={vp} front="#DA8B5C" top="#E9A67C" side="#B8693F" />
    <Box3D x={x - 6} y={y + 70} w={52} h={150} k={0.92} vp={vp} front="#B76A40" top="#D88A5E" side="#955330" />
    <Box3D x={x + w - 46} y={y + 70} w={52} h={150} k={0.92} vp={vp} front="#B76A40" top="#D88A5E" side="#955330" />
    <line x1={x + w / 2} y1={y + 152 - cushionLift * 30} x2={x + w / 2} y2={y + 212} stroke={INK_E} strokeWidth={4} />
  </g>
);

/** Rak toko: baris sandal pajangan beraneka warna. Sandal biru tua hanya satu pasang (yang dipilih). */
export const ShopRack: React.FC<{x: number; y: number; w: number; h: number; pal: Pal; blueSlot?: number; blueGone?: boolean}> = ({x, y, w, h, pal, blueSlot = 10, blueGone = false}) => {
  const shelves = 3;
  const sh = h / shelves;
  const tones = [
    {sole: '#E04B4B', soleLight: '#F07C7C', edge: '#8F2A2A', strap: '#FFC857', strapDark: '#B8861D'},
    {sole: '#F2C230', soleLight: '#F7D769', edge: '#A57E10', strap: '#E04B4B', strapDark: '#8F2A2A'},
    {sole: '#47B36B', soleLight: '#7ACD93', edge: '#26703E', strap: '#FFFFFF', strapDark: '#B8B8B8'},
    {sole: '#EE7FB3', soleLight: '#F6A9CC', edge: '#9C426F', strap: '#6A4DC4', strapDark: '#432E8A'},
  ];
  return (
    <g>
      <rect x={x} y={y} width={w} height={h} fill={pal.wood} stroke={INK_E} strokeWidth={6} />
      {Array.from({length: shelves}).map((_, r) => (
        <g key={r}>
          <rect x={x + 8} y={y + (r + 1) * sh - 16} width={w - 16} height={14} fill={pal.woodShade} stroke={INK_E} strokeWidth={3} />
          {Array.from({length: 4}).map((__, c) => {
            const isBlue = r * 4 + c === blueSlot;
            if (isBlue && blueGone) return null;
            return (
              <g key={c}>
                <Sandal x={x + 80 + c * ((w - 160) / 3) - 22} y={y + (r + 1) * sh - 78} rot={-8} scale={0.52} tilt={0.9} thick={8} colors={isBlue ? undefined : tones[(r + c) % tones.length]} />
                <Sandal x={x + 80 + c * ((w - 160) / 3) + 22} y={y + (r + 1) * sh - 78} rot={8} scale={0.52} tilt={0.9} thick={8} colors={isBlue ? undefined : tones[(r + c) % tones.length]} />
              </g>
            );
          })}
        </g>
      ))}
    </g>
  );
};

export const Counter: React.FC<{x: number; y: number; w: number; vp: Pt; pal: Pal}> = ({x, y, w, vp, pal}) => (
  <g>
    <Box3D x={x} y={y} w={w} h={190} k={0.9} vp={vp} front={mixColor(pal.wood, '#ffffff', 0.12)} top={pal.floorA} side={pal.woodShade} />
    <rect x={x + w * 0.62} y={y - 40} width={110} height={44} fill="#2B2F3A" stroke={INK_E} strokeWidth={4} />
    <rect x={x + w * 0.62 + 12} y={y - 32} width={52} height={20} fill="#9BE3A1" />
  </g>
);

export const Plant: React.FC<{x: number; y: number; s?: number; pal: Pal; t?: number}> = ({x, y, s = 1, pal, t = 0}) => (
  <g transform={`translate(${x},${y}) scale(${s})`}>
    {[-30, -12, 8, 28].map((a, i) => <Leaf key={i} x={0} y={-60} rot={a} len={120 + (i % 2) * 40} wid={26} fill={pal.leaf} shade={pal.leafShade} sway={Math.sin(t * 1.5 + i) * 2} />)}
    <path d="M -42,-70 L 42,-70 L 30,0 L -30,0 Z" fill="#B5603A" stroke={INK_E} strokeWidth={5} strokeLinejoin="round" />
  </g>
);

/* referensi agar toward tidak dianggap tak terpakai oleh linter */
export const _unused = {toward, SANDAL};
