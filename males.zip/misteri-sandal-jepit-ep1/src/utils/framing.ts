/** Hitung pusat kamera (layer depth=1) agar titik dunia (wx,wy) muncul di layar (sx,sy) pada zoom tertentu. */
export const focusOn = (wx: number, wy: number, sx: number, sy: number, zoom: number): {cx: number; cy: number} => ({
  cx: wx - (sx - 540) / zoom,
  cy: wy - (sy - 960) / zoom,
});
