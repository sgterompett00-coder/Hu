import {Easing, spring, useCurrentFrame, useVideoConfig} from 'remotion';

export type EaseName = 'lin' | 'in' | 'out' | 'io' | 'back' | 'bounce';
const EASES: Record<EaseName, (t: number) => number> = {
  lin: (t) => t,
  in: Easing.in(Easing.cubic),
  out: Easing.out(Easing.cubic),
  io: Easing.inOut(Easing.cubic),
  back: Easing.out(Easing.back(1.9)),
  bounce: Easing.out(Easing.bounce),
};

export const clamp = (v: number, a = 0, b = 1): number => Math.min(b, Math.max(a, v));
export const lerp = (a: number, b: number, k: number): number => a + (b - a) * k;
export const ease = (name: EaseName, t: number): number => EASES[name](clamp(t));

/** Keyframe: [waktu(detik), nilai, easing menuju keyframe ini]. */
export type Key = [number, number, EaseName?];
export function track(t: number, keys: Key[]): number {
  if (t <= keys[0][0]) return keys[0][1];
  for (let i = 1; i < keys.length; i++) {
    if (t <= keys[i][0]) {
      const [t0, v0] = keys[i - 1];
      const [t1, v1, e = 'io'] = keys[i];
      return lerp(v0, v1, ease(e, (t - t0) / Math.max(1e-6, t1 - t0)));
    }
  }
  return keys[keys.length - 1][1];
}

/** Waktu lokal di dalam <Sequence>. */
export function useSceneTime(): {f: number; t: number; fps: number} {
  const f = useCurrentFrame();
  const {fps} = useVideoConfig();
  return {f, t: f / fps, fps};
}

/** Skala pop dengan overshoot: 0 sebelum `start`, 1 setelah `dur`. */
export const pop = (t: number, start: number, dur = 0.28): number => (t < start ? 0 : ease('back', (t - start) / dur));

/** Spring halus berbasis frame (deterministik). */
export function useSpring(startFrame: number, damping = 12, stiffness = 180): number {
  const f = useCurrentFrame();
  const {fps} = useVideoConfig();
  return spring({frame: f - startFrame, fps, config: {damping, stiffness, mass: 0.7}});
}

/** Acak deterministik dari bilangan bulat (tanpa Math.random). */
export const hash = (n: number): number => {
  const x = Math.sin(n * 127.1 + 311.7) * 43758.5453;
  return x - Math.floor(x);
};

const hex = (c: string): [number, number, number] => {
  const h = c.replace('#', '');
  return [parseInt(h.slice(0, 2), 16), parseInt(h.slice(2, 4), 16), parseInt(h.slice(4, 6), 16)];
};
export const mixColor = (a: string, b: string, k: number): string => {
  const [r1, g1, b1] = hex(a);
  const [r2, g2, b2] = hex(b);
  const m = (x: number, y: number) => Math.round(lerp(x, y, clamp(k))).toString(16).padStart(2, '0');
  return `#${m(r1, r2)}${m(g1, g2)}${m(b1, b2)}`;
};
