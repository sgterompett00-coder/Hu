import React from 'react';
import {Camera, CamKey, Layer, Overlay} from '../components/Camera';
import {ExtFar, ExtGround, ExtHouse, ExtSky, Stage, Tree, palAt, Bush} from '../components/Environment';
import {Beam, Dust, Pool, Tint, Vignette} from '../components/Fx';
import {MainCharacter, Pose, armTip, blendPose, exprTrack, poseIdle} from '../components/MainCharacter';
import {clamp, ease, lerp, track, useSceneTime} from '../utils/anim';
import {focusOn} from '../utils/framing';

/**
 * BEAT 4 (Panel 5) — Sesuatu di depan rumah. 37,2-41,6 s (lokal 0-4,4).
 * Wide malam (rumah yang sama) -> push-in ke pintu -> karakter mengintip, ambil & nyalakan senter, sorot tanah.
 */
export const NIGHT_CHAR = {x: 334, y: 1034, scale: 0.27};

export const NightScene: React.FC = () => {
  const {f, t} = useSceneTime();
  const pal = palAt(1);
  const {x, y, scale: sc} = NIGHT_CHAR;
  const step = ease('io', clamp((t - 0.9) / 0.8));
  const cx = lerp(310, x, step);
  const cy = lerp(1010, y, step);
  const grab = ease('io', clamp((t - 2.1) / 0.4));
  const aim = ease('io', clamp((t - 2.6) / 0.5));
  const idle = poseIdle(f);
  const pose: Pose = {
    ...idle,
    armR: [lerp(lerp(idle.armR[0], -25, grab), 34, aim), lerp(lerp(idle.armR[1], 10, grab), 14, aim)],
    headRot: idle.headRot + 6 * aim,
    lean: idle.lean + 3 * aim,
  };
  const expr = exprTrack(t, [[0, 'neutral'], [1.4, 'curious'], [2.3, 'confused'], [3.3, 'suspicious']], 0.25);
  const hasLight = t >= 2.5;
  const lightOn = t >= 3.0;
  const head = focusOn(cx + 14, cy + sc * -545, 540, 880, 4.0);
  const cam: CamKey[] = [
    {t: 0, cx: 540, cy: 900, zoom: 1.0},
    {t: 1.5, cx: 500, cy: 960, zoom: 1.15, ease: 'io'},
    {t: 3.0, cx: head.cx, cy: head.cy, zoom: 3.4, ease: 'io'},
    {t: 4.4, cx: head.cx + 10, cy: head.cy + 40, zoom: 3.9, ease: 'lin'},
  ];
  const tip = armTip({x: cx, y: cy, scale: sc, dir: 1}, pose, 'R', 56);
  const flick = lightOn ? (Math.sin(f * 1.7) > 0.96 ? 0.25 : 0) : 1;
  return (
    <Camera keys={cam} handheld={t < 1.5 ? 0.3 : 0.5}>
      <Layer depth={0.15}><ExtSky k={1} t={t} /></Layer>
      <Layer depth={0.45}><ExtFar k={1} /></Layer>
      <Layer depth={1}><ExtGround k={1} /></Layer>
      <Layer depth={0.95}><ExtHouse k={1} t={t} doorOpen={1} lit={1} /></Layer>
      <Layer depth={1}>
        <Stage>
          <MainCharacter x={cx} y={cy} scale={sc} expr={expr} pose={pose} feet={{L: 'sandal', R: 'bare'}} brightness={0.78}
            flashlight={hasLight ? 'R' : null} flashlightOn={lightOn} />
          {lightOn && <Beam x={tip.x} y={tip.y} angle={tip.angle} len={520} spread={30} intensity={0.85} flicker={flick} id="nBeam" />}
          {lightOn && <Pool x={tip.x + Math.cos((tip.angle * Math.PI) / 180) * 360} y={tip.y + Math.sin((tip.angle * Math.PI) / 180) * 360} rx={120} ry={50} intensity={0.8} id="nPool" />}
        </Stage>
      </Layer>
      <Layer depth={1.4}>
        <Stage>
          <Bush x={-10} y={1990} s={1.5} pal={pal} t={t} seed={5} leaves={8} spread={110} />
          <Bush x={1090} y={1960} s={1.4} pal={pal} t={t} seed={8} leaves={8} spread={110} />
        </Stage>
      </Layer>
      <Overlay>
        <svg width={1080} height={1920} style={{position: 'absolute', left: 0, top: 0}}>
          <Dust t={t} count={18} x={0} y={500} w={1080} h={1000} color="#D8FF8A" size={3.2} seed={12} opacity={0.55} speed={0.9} />
        </svg>
      </Overlay>
      <Tint color="#3A3FA0" opacity={0.12} blend="soft-light" />
      <Vignette strength={0.55} color="2,3,20" />
    </Camera>
  );
};
void blendPose;
void Tree;
