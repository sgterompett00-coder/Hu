import React from 'react';
import {Sequence} from 'remotion';
import {Camera, CamKey, Layer, Overlay} from '../components/Camera';
import {Bush, Stage, palAt} from '../components/Environment';
import {Beam, Dust, Pool, SpeedLines, Tint, Vignette} from '../components/Fx';
import {MainCharacter, Pose, exprTrack, poseCrouch, poseIdle} from '../components/MainCharacter';
import {Footprint} from '../components/Props';
import {Sandal} from '../components/Sandal';
import {secToFrame} from '../data/beats';
import {hash, clamp, ease, lerp, track, useSceneTime} from '../utils/anim';

/**
 * BEAT 5-6 (Panel 6) — Jejak sandal + "jejak itu cuma satu". 41,6-48,7 s (lokal 0-7,1).
 * tanah 0-3,7 | jejak 3,7-4,6 | bandingkan 4,6-5,6 | wajah 5,6-7,1
 */
export const FP_SHOTS = {track: [0, 3.7], row: [3.7, 4.6], compare: [4.6, 5.6], face: [5.6, 7.1]} as const;
const VPT = {x: 700, y: 330};
/** Posisi n jejak sepanjang garis ke titik hilang: SEMUA jejak adalah sol yang sama (kaki sebelah). */
const prints = (n: number) =>
  Array.from({length: n}).map((_, i) => {
    const u = 1 - Math.pow(0.72, i); // rapat ke kejauhan
    const x = lerp(260, VPT.x, u);
    const y = lerp(1560, VPT.y + 60, u);
    return {x, y, s: lerp(1.9, 0.2, u), rot: -24 + (hash(i) - 0.5) * 6};
  });

const Ground: React.FC<{k?: number}> = ({k = 0}) => {
  const pal = palAt(1);
  return (
    <Stage>
      <defs>
        <linearGradient id="dirtG" x1="0" y1="1" x2="0.2" y2="0">
          <stop offset="0" stopColor="#7A5A40" />
          <stop offset="0.6" stopColor="#4F3A2E" />
          <stop offset="1" stopColor="#2A2230" />
        </linearGradient>
      </defs>
      <rect x={-600} y={-300} width={2280} height={2500} fill="url(#dirtG)" />
      {Array.from({length: 90}).map((_, i) => (
        <circle key={i} cx={hash(i) * 1300 - 100} cy={hash(i + 50) * 1900} r={2 + hash(i + 9) * 5} fill={i % 3 ? '#9C7A5A' : '#2A1E18'} opacity={0.5} />
      ))}
      {[[120, 700, 70], [900, 1000, 60], [820, 480, 40], [180, 1180, 50]].map(([x, y, r], i) => (
        <ellipse key={i} cx={x} cy={y} rx={r} ry={r * 0.6} fill="#6A5A52" stroke="#1A1218" strokeWidth={5} />
      ))}
      <Bush x={60} y={420} s={0.8} pal={pal} t={k} seed={2} leaves={7} spread={90} />
      <Bush x={1020} y={520} s={0.7} pal={pal} t={k} seed={6} leaves={7} spread={90} />
    </Stage>
  );
};

const ShotTrack: React.FC = () => {
  const {f, t} = useSceneTime();
  const pal = palAt(1);
  const n = 8;
  const ps = prints(n);
  const reveal = (i: number) => clamp((t - 0.35 - i * 0.28) / 0.25);
  const sweep = clamp((t - 0.2) / 3.0);
  const idx = sweep * (n - 1);
  const pi = Math.floor(idx);
  const a = ps[pi];
  const b = ps[Math.min(n - 1, pi + 1)];
  const k = idx - pi;
  const lx = lerp(a.x, b.x, k);
  const ly = lerp(a.y, b.y, k);
  const ox = 940;
  const oy = 2000;
  const ang = (Math.atan2(ly - oy, lx - ox) * 180) / Math.PI;
  const cam: CamKey[] = [
    {t: 0, cx: 540, cy: 1260, zoom: 1.25},
    {t: 3.7, cx: 640, cy: 800, zoom: 1.0, ease: 'io'},
  ];
  const ch = ease('io', clamp((t - 1.5) / 0.9));
  const pose: Pose = {...poseCrouch(ch), armR: [lerp(0, 96, ch), lerp(0, 20, ch)]};
  return (
    <Camera keys={cam} handheld={0.7}>
      <Layer depth={0.9}><Ground k={t} /></Layer>
      <Layer depth={1}>
        <Stage>
          {ps.map((p, i) => <Footprint key={i} x={p.x} y={p.y} rot={p.rot} scale={p.s} tilt={0.62} opacity={0.35 + 0.65 * reveal(i)} />)}
        </Stage>
      </Layer>
      <Layer depth={0.8} blur={3.5}>
        <Stage>
          <MainCharacter x={840} y={620} scale={0.34} dir={-1} expr={exprTrack(t, [[0, 'curious'], [2.4, 'suspicious']])} pose={pose} brightness={0.6} feet={{L: 'sandal', R: 'bare'}} />
        </Stage>
      </Layer>
      <Layer depth={1}>
        <Stage>
          <Beam x={ox} y={oy} angle={ang} len={1500} spread={22} intensity={0.75} id="fBeam" />
          <Pool x={lx} y={ly} rx={260 * a.s * 0.7 + 60} ry={150 * a.s * 0.7 + 30} intensity={0.9} id="fPool" />
        </Stage>
      </Layer>
      <Layer depth={1.5}>
        <Stage>
          <Bush x={-20} y={1960} s={1.6} pal={pal} t={t} seed={11} leaves={8} spread={100} />
          <Bush x={1100} y={1980} s={1.5} pal={pal} t={t} seed={13} leaves={8} spread={100} />
        </Stage>
      </Layer>
      <Overlay>
        <SpeedLines cx={VPT.x} cy={VPT.y} count={40} inner={620} outer={1700} color="#ffffff" opacity={0.22} seed={4} frame={f} />
        <svg width={1080} height={1920} style={{position: 'absolute', left: 0, top: 0}}>
          <Dust t={t} count={16} color="#FFE9A8" size={3} seed={7} opacity={0.5} />
        </svg>
      </Overlay>
      <Tint color="#3A3FA0" opacity={0.14} blend="soft-light" />
      <Vignette strength={0.6} color="2,3,20" />
    </Camera>
  );
};

const ShotRow: React.FC = () => {
  const {f, t} = useSceneTime();
  const ps = prints(7);
  const ring = clamp((t - 0.35) / 0.25);
  const cam: CamKey[] = [
    {t: 0, cx: 600, cy: 1100, zoom: 1.1},
    {t: 0.9, cx: 640, cy: 860, zoom: 1.45, ease: 'io'},
  ];
  return (
    <Camera keys={cam} handheld={0.5}>
      <Layer depth={0.9}><Ground k={t} /></Layer>
      <Layer depth={1}>
        <Stage>
          {ps.map((p, i) => <Footprint key={i} x={p.x} y={p.y} rot={p.rot} scale={p.s} tilt={0.62} />)}
          <Pool x={ps[2].x} y={ps[2].y} rx={300} ry={170} intensity={0.85} id="rPool" />
          <ellipse cx={ps[2].x} cy={ps[2].y} rx={230 * ring} ry={150 * ring} fill="none" stroke="#FFD93B" strokeWidth={9} strokeDasharray="30 18" opacity={ring} />
        </Stage>
      </Layer>
      <Overlay><SpeedLines cx={VPT.x} cy={VPT.y} count={40} inner={560} outer={1700} color="#ffffff" opacity={0.25} seed={9} frame={f} /></Overlay>
      <Tint color="#3A3FA0" opacity={0.14} blend="soft-light" />
      <Vignette strength={0.6} color="2,3,20" />
    </Camera>
  );
};

const ShotCompare: React.FC = () => {
  const {t} = useSceneTime();
  const step = track(t, [[0.1, 380], [0.55, 0, 'out']]);
  const cam: CamKey[] = [{t: 0, cx: 560, cy: 1180, zoom: 1.2}, {t: 1.0, cx: 560, cy: 1200, zoom: 1.45, ease: 'io'}];
  return (
    <Camera keys={cam} handheld={0.6}>
      <Layer depth={0.9}><Ground k={t} /></Layer>
      <Layer depth={1}>
        <Stage>
          <Footprint x={380} y={1260} rot={-24} scale={2.1} tilt={0.8} />
          <g transform={`translate(${step},${-step * 0.35})`}>
            <Sandal x={760} y={1250} rot={-24} scale={2.1} tilt={0.8} thick={18} />
          </g>
          <Pool x={560} y={1260} rx={520} ry={260} intensity={0.8} id="cPool" />
        </Stage>
      </Layer>
      <Tint color="#3A3FA0" opacity={0.14} blend="soft-light" />
      <Vignette strength={0.6} color="2,3,20" />
    </Camera>
  );
};

const ShotFace: React.FC = () => {
  const {f, t} = useSceneTime();
  const sc = 0.62;
  const x = 520;
  const y = 1700;
  const zoom0 = 300 / (130 * sc);
  const headY = y + sc * -545;
  const expr = exprTrack(t, [[0, 'confused'], [0.5, 'suspicious'], [1.0, 'nervous']], 0.25);
  const turn = track(t, [[0, -4], [1.0, 2], [1.3, 12, 'io'], [1.5, 12]]);
  const shake = Math.sin(f * 2.4) * 5;
  const pose: Pose = {...poseIdle(f), headRot: turn, armR: [24 + shake * 0.2, 28]};
  const cam: CamKey[] = [
    {t: 0, cx: x, cy: headY + 90, zoom: zoom0 * 0.85},
    {t: 1.5, cx: x + 20, cy: headY + 40, zoom: zoom0 * 1.2, ease: 'io'},
  ];
  return (
    <Camera keys={cam} handheld={0.6}>
      <Layer depth={0.9}>
        <Stage>
          <rect x={-500} y={-400} width={2080} height={2600} fill="#1B2150" />
          <circle cx={820} cy={420} r={50} fill="#FFF4C8" opacity={0.8} />
        </Stage>
      </Layer>
      <Layer depth={1}>
        <Stage>
          <MainCharacter x={x} y={y} scale={sc} expr={expr} pose={pose} brightness={0.72} feet={{L: 'sandal', R: 'bare'}} flashlight="R" />
        </Stage>
      </Layer>
      <Tint color="#3A3FA0" opacity={0.2} blend="soft-light" />
      <Vignette strength={0.6} color="2,3,20" />
    </Camera>
  );
};

export const FootprintScene: React.FC = () => {
  const S = FP_SHOTS;
  const seq = (k: keyof typeof S, C: React.FC) => (
    <Sequence from={secToFrame(S[k][0])} durationInFrames={secToFrame(S[k][1]) - secToFrame(S[k][0])} name={k}>
      <C />
    </Sequence>
  );
  return (
    <>
      {seq('track', ShotTrack)}
      {seq('row', ShotRow)}
      {seq('compare', ShotCompare)}
      {seq('face', ShotFace)}
    </>
  );
};
