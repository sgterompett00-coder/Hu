import React from 'react';
import {Camera, CamKey, Layer, Overlay} from '../components/Camera';
import {Bush, Stage, palAt} from '../components/Environment';
import {Beam, Dust, ImpactLines, Pool, SpeedLines, Tint, Vignette} from '../components/Fx';
import {MainCharacter, basePose, EXPR} from '../components/MainCharacter';
import {Sandal} from '../components/Sandal';
import {hash, track, useSceneTime} from '../utils/anim';

/**
 * BEAT 8 (Panel 8) — Penemuan misterius. 51,0-54,7 s (lokal 0-3,7).
 * Extreme close-up satu sandal biru di balik semak, shallow DOF, push-in pelan, gerakan sandal sangat halus dan ambigu.
 * TIDAK menampilkan pelaku.
 */
export const DiscoveryScene: React.FC = () => {
  const {f, t} = useSceneTime();
  const pal = palAt(1);
  const rustle = track(t, [[0, 0.3], [1.6, 0.4], [2.0, 1], [2.7, 1], [3.1, 0.35]]);
  const twitch = track(t, [[1.9, 0], [2.1, 1], [2.25, -0.6], [2.4, 0.4], [2.6, 0]]);
  const cam: CamKey[] = [
    {t: 0, cx: 540, cy: 1000, zoom: 1.0},
    {t: 3.2, cx: 546, cy: 1010, zoom: 1.75, ease: 'io'},
    {t: 3.7, cx: 546, cy: 1012, zoom: 2.15, ease: 'in'},
  ];
  const sway = (i: number) => Math.sin(t * 13 + i * 2.1) * 1.8 * rustle;
  return (
    <Camera keys={cam} handheld={0.5}>
      <Layer depth={0.8} blur={2.5}>
        <Stage>
          <defs>
            <radialGradient id="dG" cx="50%" cy="52%" r="70%">
              <stop offset="0" stopColor="#6B5444" />
              <stop offset="0.6" stopColor="#3C2E2A" />
              <stop offset="1" stopColor="#171220" />
            </radialGradient>
          </defs>
          <rect x={-600} y={-400} width={2280} height={2700} fill="url(#dG)" />
          {Array.from({length: 70}).map((_, i) => <circle key={i} cx={hash(i) * 1200 - 60} cy={600 + hash(i + 40) * 900} r={2 + hash(i + 9) * 4} fill={i % 3 ? '#8E6F55' : '#20161A'} opacity={0.55} />)}
          {[[160, 520, 1.9], [540, 380, 1.5], [940, 520, 1.9]].map(([x, y, s], i) => (
            <g key={i} transform={`rotate(${sway(i)} ${x} ${y + 300})`}><Bush x={x} y={y + 330} s={s} pal={pal} t={t} seed={40 + i} leaves={9} spread={120} /></g>
          ))}
        </Stage>
      </Layer>
      <Layer depth={1}>
        <Stage>
          <Pool x={540} y={1010} rx={520} ry={330} intensity={0.55} id="dPool" />
          <Beam x={-120} y={-80} angle={46} len={1700} spread={24} intensity={0.5} id="dBeam" />
          <ellipse cx={560} cy={1130} rx={290} ry={70} fill="#000" opacity={0.4} />
          <Sandal x={540 + twitch * 5} y={1010} rot={14 + twitch * 3} scale={2.3} tilt={0.62} thick={20} />
        </Stage>
      </Layer>
      <Layer depth={1.25}>
        <Stage>
          {[[40, 1500, 1.7], [1040, 1470, 1.6], [230, 1760, 1.5], [880, 1740, 1.5]].map(([x, y, s], i) => (
            <g key={i} transform={`rotate(${sway(i + 5)} ${x} ${y})`}><Bush x={x} y={y + 300} s={s} pal={pal} t={t} seed={60 + i} leaves={9} spread={120} /></g>
          ))}
        </Stage>
      </Layer>
      <Layer depth={1.6} blur={9}>
        <Stage>
          <MainCharacter x={110} y={2230} scale={1.8} back expr={EXPR.neutral} pose={basePose()} brightness={0.3} flashlight="R" />
        </Stage>
      </Layer>
      <Overlay>
        <SpeedLines cx={540} cy={1000} count={26} inner={720} outer={1800} color="#ffffff" opacity={0.3} seed={8} frame={f} />
        <svg width={1080} height={1920} style={{position: 'absolute', left: 0, top: 0}}>
          <ImpactLines x={760} y={220} rot={-8} scale={1.5} t={t} start={0.25} />
          <Dust t={t} count={14} x={100} y={500} w={880} h={900} color="#D8FF8A" size={3} seed={17} opacity={0.5} />
        </svg>
      </Overlay>
      <Tint color="#3A3FA0" opacity={0.14} blend="soft-light" />
      <Vignette strength={0.6} color="2,3,20" />
    </Camera>
  );
};
