import React from 'react';
import {Sequence} from 'remotion';
import {Camera, CamKey, Layer, Overlay} from '../components/Camera';
import {Stage, palAt} from '../components/Environment';
import {Dust, ImpactLines, Tint, Vignette} from '../components/Fx';
import {MainCharacter, Pose, basePose, blendPose, exprTrack, poseCrouch, poseFloorSit, poseIdle, poseWalk} from '../components/MainCharacter';
import {Bed, Bookshelf, Counter, Fridge, Plant, Sofa, Wardrobe, WindowRoom} from '../components/Props';
import {ROOM_VP, RoomBase, roomScale} from './rooms';
import {secToFrame} from '../data/beats';
import {clamp, ease, lerp, track, useSceneTime} from '../utils/anim';
import {focusOn} from '../utils/framing';

/**
 * BEAT 2 (Panel 3) — Mencari ke seluruh rumah. 11,2-24,1 s (lokal 0-12,9 s).
 * living 0-3,1 | kamar 3,1-4,2 | dapur 4,2-5,8 | bawah kasur 5,8-8,8 | duduk berpikir 8,8-12,9
 */
export const SEARCH_SHOTS = {living: [0, 3.1], bedroom: [3.1, 4.2], kitchen: [4.2, 5.8], under: [5.8, 8.8], thinking: [8.8, 12.9]} as const;
const pal = palAt(0);

const Atmos: React.FC<{t: number; warm?: number}> = ({t, warm = 0.08}) => (
  <>
    <Overlay>
      <svg width={1080} height={1920} style={{position: 'absolute', left: 0, top: 0}}>
        <Dust t={t} count={16} x={100} y={300} w={880} h={1100} color="#FFF3C4" size={3} seed={9} opacity={0.5} />
      </svg>
    </Overlay>
    <Tint color="#FFE2A0" opacity={warm} blend="soft-light" />
    <Vignette strength={0.3} color="30,20,10" />
  </>
);

/* ---------------------------- 1. RUANG TENGAH ---------------------------- */
const ShotLiving: React.FC = () => {
  const {f, t} = useSceneTime();
  const open = track(t, [[0.25, 0], [0.85, 1, 'out'], [1.7, 1], [2.1, 0.15]]);
  const lift = track(t, [[2.25, 0], [2.55, 1, 'out'], [3.0, 1]]);
  const dir: 1 | -1 = t < 1.55 ? 1 : -1;
  const x = track(t, [[0, 520], [0.3, 590], [1.55, 590], [2.25, 450, 'io']]);
  const y = 1470;
  const sc = roomScale(y);
  const walkIn = t < 0.3 ? 1 - ease('io', clamp(t / 0.3)) : 0;
  const walkOut = t >= 1.55 && t < 2.25 ? 1 : 0;
  let pose: Pose = poseIdle(f);
  if (walkIn > 0 || walkOut) pose = blendPose(pose, poseWalk(f, 0.26), walkIn > 0 ? walkIn : 1);
  const reach = ease('io', clamp((t - 0.3) / 0.35)) * (1 - ease('io', clamp((t - 1.5) / 0.2)));
  const peek = ease('io', clamp((t - 0.85) / 0.4)) * (1 - ease('io', clamp((t - 1.45) / 0.2)));
  const crouch = ease('io', clamp((t - 2.0) / 0.4));
  pose = {
    ...pose,
    armR: [lerp(pose.armR[0], 108, reach), lerp(pose.armR[1], 44, reach)],
    lean: pose.lean + 15 * peek,
    headRot: pose.headRot + 10 * peek + (t > 1.5 && t < 1.95 ? Math.sin(t * 34) * 7 : 0),
  };
  if (crouch > 0) {
    const c = poseCrouch(0.62);
    pose = blendPose(pose, {...c, armR: [70, 18], armL: [30, 30]}, crouch);
  }
  const expr = exprTrack(t, [[0, 'confident'], [0.85, 'curious'], [1.5, 'confused'], [2.3, 'suspicious']]);
  const cam: CamKey[] = [
    {t: 0, cx: 560, cy: 1010, zoom: 1.05},
    {t: 1.4, cx: 620, cy: 1040, zoom: 1.35, ease: 'io'},
    {t: 2.2, cx: 480, cy: 1090, zoom: 1.45, ease: 'io'},
    {t: 3.1, cx: 470, cy: 1130, zoom: 1.6, ease: 'lin'},
  ];
  return (
    <Camera keys={cam} handheld={0.9}>
      <Layer depth={0.96}><Stage><RoomBase kind="living" pal={pal} /></Stage></Layer>
      <Layer depth={1}>
        <Stage>
          <WindowRoom x={250} y={520} w={160} h={200} pal={pal} />
          <Plant x={500} y={1388} s={0.8} pal={pal} t={t} />
          <Sofa x={150} y={1178} w={330} vp={ROOM_VP} cushionLift={lift} />
          <Wardrobe x={700} y={788} w={200} h={600} vp={ROOM_VP} pal={pal} open={open} />
          <MainCharacter x={x} y={y} scale={sc} dir={dir} expr={expr} pose={pose} feet={{L: 'sandal', R: 'bare'}} />
          {t > 2.5 && <ImpactLines x={x - 140} y={y - 330} rot={-20} scale={0.55} t={t} start={2.55} />}
        </Stage>
      </Layer>
      <Atmos t={t} />
    </Camera>
  );
};

/* ---------------------------------- 2. KAMAR ---------------------------------- */
const BedroomProps: React.FC<{lift?: number; under?: boolean; bedX?: number}> = ({lift = 0, under = false, bedX = 330}) => (
  <>
    <WindowRoom x={560} y={520} w={170} h={200} pal={pal} />
    <Bookshelf x={140} y={810} w={150} h={578} pal={pal} />
    <Bed x={bedX} y={1010} w={520} h={380} vp={ROOM_VP} pal={pal} lift={lift} />
    {under && (
      <g>
        <rect x={bedX + 40} y={1260} width={440} height={110} fill="#150E10" opacity={0.92} />
        {[[bedX + 120, 1350, 20], [bedX + 300, 1356, 14], [bedX + 400, 1346, 17]].map(([cx, cy, r], i) => (
          <ellipse key={i} cx={cx} cy={cy} rx={r} ry={r * 0.55} fill="#6E6568" opacity={0.8} />
        ))}
      </g>
    )}
  </>
);

const ShotBedroom: React.FC = () => {
  const {f, t} = useSceneTime();
  const y = 1480;
  const sc = roomScale(y);
  const lift = track(t, [[0.25, 0], [0.5, 0.45, 'out'], [0.85, 0.45], [1.0, 0, 'in']]);
  const reach = ease('io', clamp((t - 0.15) / 0.2)) * (1 - ease('io', clamp((t - 0.85) / 0.15)));
  const pose: Pose = {...poseIdle(f), armR: [lerp(0, 120, reach), lerp(0, 40, reach)], lean: 10 * reach, headRot: 8 * reach};
  const expr = exprTrack(t, [[0, 'curious'], [0.55, 'confused']]);
  const cam: CamKey[] = [
    {t: 0, cx: 540, cy: 1060, zoom: 1.3},
    {t: 0.75, cx: 540, cy: 1070, zoom: 1.4, ease: 'lin'},
    {t: 1.1, cx: 940, cy: 1070, zoom: 1.4, ease: 'in'},
  ];
  return (
    <Camera keys={cam}>
      <Layer depth={0.96}><Stage><RoomBase kind="bedroom" pal={pal} /></Stage></Layer>
      <Layer depth={1}>
        <Stage>
          <BedroomProps lift={lift} />
          <MainCharacter x={430} y={y} scale={sc} expr={expr} pose={pose} feet={{L: 'sandal', R: 'bare'}} />
        </Stage>
      </Layer>
      <Atmos t={t} />
    </Camera>
  );
};

/* ---------------------------------- 3. DAPUR ---------------------------------- */
const ShotKitchen: React.FC = () => {
  const {f, t} = useSceneTime();
  const y = 1490;
  const sc = roomScale(y);
  const open = track(t, [[0.4, 0], [0.95, 1, 'out']]);
  const peek = ease('io', clamp((t - 0.95) / 0.35));
  const reach = ease('io', clamp((t - 0.3) / 0.25));
  const pose: Pose = {
    ...poseIdle(f),
    armR: [lerp(0, 112, reach), lerp(0, 36, reach)],
    lean: 16 * peek,
    headRot: 6 * peek,
  };
  const expr = exprTrack(t, [[0, 'confused'], [0.5, 'neutral'], [1.0, 'suspicious']], 0.2);
  const cam: CamKey[] = [
    {t: 0, cx: 130, cy: 1070, zoom: 1.4},
    {t: 0.3, cx: 560, cy: 1080, zoom: 1.4, ease: 'out'},
    {t: 1.6, cx: 600, cy: 1110, zoom: 1.65, ease: 'io'},
  ];
  const spill = 0.55 * open;
  return (
    <Camera keys={cam}>
      <Layer depth={0.96}><Stage><RoomBase kind="kitchen" pal={pal} /></Stage></Layer>
      <Layer depth={1}>
        <Stage>
          <WindowRoom x={190} y={560} w={160} h={200} pal={pal} />
          <Counter x={130} y={1198} w={340} vp={ROOM_VP} pal={pal} />
          <Fridge x={640} y={800} w={230} h={588} vp={ROOM_VP} open={open} />
          {open > 0.05 && <polygon points="640,1100 860,1100 1000,1560 560,1560" fill="#FFFBE0" opacity={spill * 0.55} style={{mixBlendMode: 'screen'}} />}
          <MainCharacter x={500} y={y} scale={sc} expr={expr} pose={pose} feet={{L: 'sandal', R: 'bare'}} />
          {open > 0.3 && <Dust t={t} count={14} x={600} y={1100} w={220} h={380} color="#E6F6FF" size={5} seed={21} speed={0.7} opacity={0.65} />}
        </Stage>
      </Layer>
      <Atmos t={t} />
    </Camera>
  );
};

/* -------------------------------- 4. BAWAH KASUR -------------------------------- */
const ShotUnder: React.FC = () => {
  const {f, t} = useSceneTime();
  const y = 1570;
  const sc = roomScale(y);
  const lift = track(t, [[0.7, 0], [1.3, 1, 'out'], [2.5, 1], [2.9, 0.6]]);
  const crouch = ease('io', clamp((t - 0.1) / 0.6));
  const look = ease('io', clamp((t - 1.0) / 0.6));
  const base = poseCrouch(crouch);
  const pose: Pose = {
    ...base,
    armR: [lerp(base.armR[0], 78, ease('io', clamp((t - 0.5) / 0.4))), lerp(base.armR[1], 16, ease('io', clamp((t - 0.5) / 0.4)))],
    lean: base.lean + 18 * look,
    headRot: base.headRot + 10 * look + Math.sin(t * 5) * 1.5,
    headDy: 14 * look,
  };
  const expr = exprTrack(t, [[0, 'confident'], [0.7, 'suspicious'], [2.0, 'neutral']], 0.3);
  const cam: CamKey[] = [
    {t: 0, cx: 540, cy: 1250, zoom: 1.3, rot: -2},
    {t: 1.0, cx: 500, cy: 1330, zoom: 1.75, rot: -3, ease: 'io'},
    {t: 3.0, cx: 480, cy: 1390, zoom: 2.15, rot: -4, ease: 'io'},
  ];
  return (
    <Camera keys={cam} handheld={0.8}>
      <Layer depth={0.96}><Stage><RoomBase kind="bedroom" pal={pal} /></Stage></Layer>
      <Layer depth={1}>
        <Stage>
          <BedroomProps lift={lift} under bedX={440} />
          <MainCharacter x={330} y={y} scale={sc} expr={expr} pose={pose} feet={{L: 'sandal', R: 'bare'}} />
          {t > 1.2 && <ImpactLines x={510} y={1180} rot={-30} scale={0.5} t={t} start={1.25} />}
        </Stage>
      </Layer>
      <Atmos t={t} />
    </Camera>
  );
};

/* ------------------------------- 5. DUDUK BERPIKIR ------------------------------- */
export const THINK_FACE = {x: 470, y: 1560, scale: 0.9, zoom: 300 / (130 * 0.9)};
const ShotThinking: React.FC = () => {
  const {f, t} = useSceneTime();
  const {x, y, scale: sc} = THINK_FACE;
  const scratch = ease('io', clamp((t - 0.8) / 0.4));
  const wig = Math.sin(t * 18) * 6 * scratch;
  const pose: Pose = {
    ...blendPose(poseFloorSit(), poseFloorSit(), 0),
    headRot: Math.sin(t * 2.2) * 5 + 8 * scratch,
    armR: [lerp(10, 136 + wig, scratch), lerp(20, 64, scratch)],
    lean: 3 + Math.sin(t * 1.6) * 1.5,
  };
  const px = track(t, [[0, 0.4], [1.2, -0.8], [1.9, 0.8], [2.6, -0.7], [3.4, 0.7], [4.1, 0.1]]);
  const e0 = exprTrack(t, [[0, 'thinking'], [1.4, 'suspicious']], 0.35);
  const expr = {...e0, px};
  const headY = y + sc * (-545 + 212);
  const end = focusOn(x, headY, 540, 830, THINK_FACE.zoom);
  const cam: CamKey[] = [
    {t: 0, cx: 520, cy: 1230, zoom: 1.7},
    {t: 2.4, cx: 500, cy: 1260, zoom: 2.0, ease: 'io'},
    {t: 4.1, cx: end.cx, cy: end.cy, zoom: THINK_FACE.zoom, ease: 'io'},
  ];
  return (
    <Camera keys={cam}>
      <Layer depth={0.96}><Stage><RoomBase kind="bedroom" pal={pal} /></Stage></Layer>
      <Layer depth={1}>
        <Stage>
          <BedroomProps bedX={440} />
          <MainCharacter x={x} y={y} scale={sc} expr={expr} pose={pose} feet={{L: 'sandal', R: 'bare'}} />
        </Stage>
      </Layer>
      <Atmos t={t} warm={0.05} />
    </Camera>
  );
};

export const SearchScene: React.FC = () => {
  const S = SEARCH_SHOTS;
  const seq = (k: keyof typeof S, C: React.FC) => (
    <Sequence from={secToFrame(S[k][0])} durationInFrames={secToFrame(S[k][1]) - secToFrame(S[k][0])} name={k}>
      <C />
    </Sequence>
  );
  return (
    <>
      {seq('living', ShotLiving)}
      {seq('bedroom', ShotBedroom)}
      {seq('kitchen', ShotKitchen)}
      {seq('under', ShotUnder)}
      {seq('thinking', ShotThinking)}
    </>
  );
};
void basePose;
