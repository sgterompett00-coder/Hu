import React from 'react';
import {Sequence} from 'remotion';
import {Camera, CamKey, Layer, Overlay} from '../components/Camera';
import {PerspFloor, Stage, palAt} from '../components/Environment';
import {Dust, ImpactLines, QMark, SpeedLines, Tint, Vignette} from '../components/Fx';
import {MainCharacter, Pose, blendPose, exprTrack, poseIdle, poseWalk} from '../components/MainCharacter';
import {Calendar, Counter, ShopRack} from '../components/Props';
import {SandalPair, Sandal} from '../components/Sandal';
import {SandalPile} from '../components/Props';
import {ROOM_VP, RoomBase, roomScale} from './rooms';
import {secToFrame} from '../data/beats';
import {clamp, ease, lerp, pop, track, useSceneTime} from '../utils/anim';
import {focusOn} from '../utils/framing';

/**
 * BEAT 3 (Panel 4) — Sandal baru, masalah lama. 24,1-37,2 s (lokal 0-13,1).
 * toko 0-2,4 | besoknya 2,4-5,8 | montage 3x0,8 s 5,8-8,2 | tumpukan 8,2-10,2 | curiga + dusk 10,2-13,1
 */
export const NEW_SHOTS = {shop: [0, 2.4], day: [2.4, 5.8], montage: [5.8, 8.2], pile: [8.2, 10.2], suspect: [10.2, 13.1]} as const;

/** Kerangka cocok-potong dari ShotThinking: wajah di (540,830) berjari-jari 300 px. */
const MATCH = {x: 520, y: 1440};
const MATCH_SC = roomScale(MATCH.y);
const MATCH_ZOOM = 300 / (130 * MATCH_SC);

const Warm: React.FC<{t: number}> = ({t}) => (
  <>
    <Overlay>
      <svg width={1080} height={1920} style={{position: 'absolute', left: 0, top: 0}}>
        <Dust t={t} count={12} x={100} y={300} w={880} h={1100} color="#FFF3C4" size={3} seed={4} opacity={0.45} />
      </svg>
    </Overlay>
    <Tint color="#FFE2A0" opacity={0.07} blend="soft-light" />
    <Vignette strength={0.28} color="30,20,10" />
  </>
);

/* ---------------------------------- TOKO ---------------------------------- */
const ShotShop: React.FC = () => {
  const {f, t} = useSceneTime();
  const pal = palAt(0);
  const sc = MATCH_SC;
  const x = track(t, [[0, MATCH.x], [1.0, 440], [1.9, 440], [2.4, 760, 'io']]);
  const y = MATCH.y;
  const reach = ease('io', clamp((t - 0.55) / 0.3)) * (1 - ease('io', clamp((t - 0.95) / 0.25)));
  const hold = ease('io', clamp((t - 1.1) / 0.3));
  const pick = t >= 0.9;
  const walk = t > 1.9 ? 1 : 0;
  let pose: Pose = walk ? poseWalk(f, 0.24) : poseIdle(f);
  pose = {
    ...pose,
    armR: [lerp(lerp(pose.armR[0], 40, reach), 62, hold), lerp(lerp(pose.armR[1], 28, reach), 66, hold)],
    armL: [lerp(pose.armL[0], 52, hold), lerp(pose.armL[1], 70, hold)],
    lean: pose.lean + 8 * reach,
    headRot: pose.headRot + 6 * reach,
  };
  const expr = exprTrack(t, [[0, 'suspicious'], [0.4, 'curious'], [1.0, 'happy'], [1.8, 'confident']], 0.22);
  const startC = focusOn(MATCH.x, y + MATCH_SC * -545, 540, 830, MATCH_ZOOM);
  const cam: CamKey[] = [
    {t: 0, cx: startC.cx, cy: startC.cy, zoom: MATCH_ZOOM},
    {t: 0.3, cx: startC.cx, cy: startC.cy, zoom: MATCH_ZOOM, ease: 'lin'},
    {t: 1.0, cx: 540, cy: 1130, zoom: 1.45, ease: 'io'},
    {t: 2.4, cx: 600, cy: 1150, zoom: 1.4, ease: 'io'},
  ];
  return (
    <Camera keys={cam} handheld={0.3}>
      <Layer depth={0.96}>
        <Stage>
          <RoomBase kind="shop" pal={pal} />
          {[0, 1, 2, 3, 4, 5].map((i) => (
            <polygon key={i} points={`${160 + i * 130},430 ${290 + i * 130},430 ${270 + i * 130},510 ${180 + i * 130},510`} fill={i % 2 ? '#fff' : '#E04B4B'} stroke="#14141A" strokeWidth={4} />
          ))}
        </Stage>
      </Layer>
      <Layer depth={1}>
        <Stage>
          <ShopRack x={150} y={860} w={440} h={528} pal={pal} blueGone={pick} />
          <Counter x={660} y={1198} w={300} vp={ROOM_VP} pal={pal} />
          <MainCharacter
            x={x} y={y} scale={sc} expr={expr} pose={pose} feet={{L: 'sandal', R: 'bare'}}
            front={hold > 0.05 ? <g transform="translate(205,-355)"><SandalPair scale={0.55} rot={-12} /></g> : null}
          />
          {t > 2.0 && <ImpactLines x={770} y={1120} rot={-10} scale={0.5} t={t} start={2.0} />}
        </Stage>
      </Layer>
      <Warm t={t} />
    </Camera>
  );
};

/* ------------------------------- BESOKNYA ------------------------------- */
const DayBg: React.FC<{wall?: string}> = ({wall = '#F4E8D0'}) => (
  <Stage>
    <rect x={-500} y={-400} width={2080} height={1650} fill={wall} />
    <rect x={-500} y={1190} width={2080} height={60} fill="#D9C6A0" opacity={0.7} />
    <PerspFloor vp={[540, 1050]} nearY={2300} farY={1250} x0={-9000} x1={10000} cols={36} rows={11} a="#C99A6B" b="#BD8B5C" grout="rgba(60,30,10,0.35)" gw={3} />
  </Stage>
);

const ShotDay: React.FC = () => {
  const {f, t} = useSceneTime();
  const calIn = pop(t, 0.05, 0.4);
  const circle = clamp((t - 0.55) / 0.55);
  const banner = pop(t, 0.2, 0.3);
  const drop = track(t, [[1.0, -700], [1.3, 0, 'in'], [1.42, -50, 'out'], [1.55, 0, 'in']]);
  const squash = t > 1.28 && t < 1.5 ? 0.78 : 1;
  const cx = track(t, [[1.6, -160], [2.3, 270, 'io']]);
  const walking = t >= 1.6 && t < 2.3;
  const pose: Pose = walking ? poseWalk(f, 0.24) : poseIdle(f);
  const react = ease('io', clamp((t - 2.5) / 0.3));
  const expr = exprTrack(t, [[0, 'happy'], [2.3, 'confused'], [2.55, 'shocked'], [2.95, 'suspicious']], 0.15);
  const cam: CamKey[] = [{t: 0, cx: 540, cy: 960, zoom: 1.0}, {t: 3.4, cx: 560, cy: 1000, zoom: 1.14, ease: 'io'}];
  return (
    <Camera keys={cam} handheld={0.4}>
      <Layer depth={0.9}><DayBg /></Layer>
      <Layer depth={1}>
        <Stage>
          <Calendar x={520} y={250} w={460} h={360} rot={-5} scale={calIn} circle={circle} banner={banner} day={0} />
          <ellipse cx={720} cy={1530} rx={120} ry={22} fill="#000" opacity={0.2} />
          <g transform={`translate(0,${drop}) translate(720,1500) scale(1,${squash}) translate(-720,-1500)`}>
            <Sandal x={720} y={1500} rot={38} tilt={0.62} scale={1.5} thick={14} />
          </g>
          {t > 1.3 && <ImpactLines x={850} y={1380} rot={-6} scale={0.9} t={t} start={1.3} />}
          {t >= 1.6 && <MainCharacter x={cx} y={1600} scale={0.85} expr={expr} pose={{...pose, lean: pose.lean + 8 * react}} feet={{L: 'sandal', R: 'bare'}} />}
          {t > 2.55 && <g transform="translate(330,880)"><QMark x={0} y={0} scale={0.6 * pop(t, 2.95, 0.3)} rot={10} /></g>}
        </Stage>
      </Layer>
      <Warm t={t} />
    </Camera>
  );
};

/* -------------------------------- MONTAGE -------------------------------- */
const BG = ['#FFE08A', '#A5DCF5', '#FFC1D4'];
const MontageUnit: React.FC<{k: number}> = ({k}) => {
  const {f, t} = useSceneTime();
  const charIn = ease('out', clamp(t / 0.14));
  const calIn = pop(t, 0.26, 0.18);
  const slam = t >= 0.52 ? 1 : 0;
  const drop = track(t, [[0.52, -500], [0.62, 0, 'in']]);
  const shake = t > 0.62 && t < 0.78 ? Math.sin(f * 3.1) * 10 * (1 - (t - 0.62) / 0.16) : 0;
  const expr = exprTrack(t, [[0, 'happy'], [0.5, 'shocked']], 0.08);
  const pose: Pose = {...poseIdle(f), armR: [58, 66], armL: [48, 70]};
  return (
    <Camera keys={[{t: 0, cx: 540, cy: 960, zoom: 1}]} motionBlur={false}>
      <Layer depth={1}>
        <Stage>
          <rect x={-100} y={-100} width={1300} height={2100} fill={BG[k]} />
        </Stage>
        <SpeedLines cx={540} cy={900} count={44} inner={300} outer={1700} color="#ffffff" opacity={0.55} seed={k + 2} frame={f} />
      </Layer>
      <Layer depth={1}>
        <Stage>
          <g transform={`translate(${shake},0)`}>
            <MainCharacter x={270 - (1 - charIn) * 500} y={1520} scale={0.9} expr={expr} pose={pose} feet={{L: 'sandal', R: 'bare'}}
              front={t < 0.5 ? <g transform="translate(205,-355)"><SandalPair scale={0.55} rot={-12} /></g> : null} />
            <Calendar x={560} y={220} w={420} h={330} rot={-4} scale={calIn} circle={clamp((t - 0.3) / 0.2)} banner={0} day={k + 1} />
            <SandalPile x={760} y={1560} n={k + 1} scale={1.15} />
            {slam > 0 && <g transform={`translate(0,${drop})`}><Sandal x={790} y={1470 - k * 20} rot={20 + k * 30} tilt={0.62} scale={1.3} thick={14} /></g>}
            {t > 0.6 && <ImpactLines x={930} y={1380} rot={-6} scale={0.8} t={t} start={0.6} />}
          </g>
        </Stage>
      </Layer>
      {[0.26, 0.5].map((s, i) => t > s && t < s + 0.14 && (
        <Overlay key={i}>
          {[300, 800, 1300].map((yy, j) => <div key={j} style={{position: 'absolute', left: -200 + ((t - s) / 0.14) * 1500, top: yy + j * 40, width: 520, height: 14, background: '#fff', opacity: 0.8, borderRadius: 7}} />)}
        </Overlay>
      ))}
    </Camera>
  );
};
const ShotMontage: React.FC = () => (
  <>
    {[0, 1, 2].map((k) => (
      <Sequence key={k} from={secToFrame(k * 0.8)} durationInFrames={secToFrame(0.8)} name={`montage-${k}`}>
        <MontageUnit k={k} />
      </Sequence>
    ))}
  </>
);

/* --------------------------------- TUMPUKAN --------------------------------- */
const ShotPile: React.FC = () => {
  const {t} = useSceneTime();
  const cam: CamKey[] = [
    {t: 0, cx: 540, cy: 1200, zoom: 1.0, rot: 0},
    {t: 2.0, cx: 560, cy: 1480, zoom: 2.4, rot: -3, ease: 'in'},
  ];
  return (
    <Camera keys={cam} handheld={0.9}>
      <Layer depth={0.9}><DayBg wall="#E9DBC0" /></Layer>
      <Layer depth={1}>
        <Stage>
          <ellipse cx={560} cy={1520} rx={400} ry={70} fill="#000" opacity={0.22} />
          <SandalPile x={560} y={1500} n={8} scale={1.35} />
        </Stage>
      </Layer>
      <Tint color="#2B2F6B" opacity={track(t, [[0, 0.0], [2.0, 0.28]])} blend="multiply" />
      <Vignette strength={0.45} color="10,10,30" />
    </Camera>
  );
};

/* ---------------------------- CURIGA + MENUJU MALAM ---------------------------- */
const ShotSuspect: React.FC = () => {
  const {f, t} = useSceneTime();
  const sc = 0.9;
  const x = 540;
  const y = 1560;
  const zoom0 = 300 / (130 * sc);
  const fc = focusOn(x, y + sc * -545, 540, 830, zoom0);
  const px = track(t, [[0, 0.1], [0.6, -0.9], [1.4, 0.9], [2.0, -0.8], [2.6, 0.7], [2.9, 0.3]]);
  const turn = track(t, [[0, 0], [0.6, -9], [1.4, 9], [2.0, -8], [2.6, 7], [2.9, 0]]);
  const expr = {...exprTrack(t, [[0, 'suspicious'], [1.6, 'suspicious']]), px, lid: 0.55};
  const pose: Pose = {...poseIdle(f), headRot: turn};
  const dusk = track(t, [[0, 0.0], [2.9, 0.62]]);
  const cam: CamKey[] = [
    {t: 0, cx: fc.cx, cy: fc.cy, zoom: zoom0},
    {t: 2.9, cx: fc.cx, cy: fc.cy + 10, zoom: zoom0 * 1.12, ease: 'io'},
  ];
  return (
    <Camera keys={cam} handheld={0.5}>
      <Layer depth={0.9}>
        <Stage>
          <rect x={-500} y={-400} width={2080} height={2600} fill="#F0DFC0" />
          <rect x={160} y={300} width={300} height={380} fill="#9AD3F2" stroke="#14141A" strokeWidth={6} />
          <rect x={620} y={380} width={260} height={340} fill="#EFD9A8" opacity={0.5} />
        </Stage>
      </Layer>
      <Layer depth={1}>
        <Stage>
          <MainCharacter x={x} y={y} scale={sc} expr={expr} pose={pose} feet={{L: 'sandal', R: 'bare'}} />
        </Stage>
      </Layer>
      <Tint color="#FF9B4A" opacity={track(t, [[0, 0.0], [1.2, 0.18], [2.9, 0.0]])} blend="soft-light" />
      <Tint color="#1B2056" opacity={dusk} blend="normal" />
      <Vignette strength={0.5} color="8,8,30" />
    </Camera>
  );
};

export const NewSandalScene: React.FC = () => {
  const S = NEW_SHOTS;
  const seq = (k: keyof typeof S, C: React.FC) => (
    <Sequence from={secToFrame(S[k][0])} durationInFrames={secToFrame(S[k][1]) - secToFrame(S[k][0])} name={k}>
      <C />
    </Sequence>
  );
  return (
    <>
      {seq('shop', ShotShop)}
      {seq('day', ShotDay)}
      {seq('montage', ShotMontage)}
      {seq('pile', ShotPile)}
      {seq('suspect', ShotSuspect)}
    </>
  );
};
void blendPose;
void Overlay;
