import React from 'react';
import {Camera, CamKey, Layer, Overlay} from '../components/Camera';
import {Box3D, FenceLine, PerspFloor, Pt, Stage, Bush, NIGHT, palAt, toward} from '../components/Environment';
import {Beam, Dust, Pool, Tint, Vignette} from '../components/Fx';
import {MainCharacter, Pose, armTip, exprTrack, poseWalk} from '../components/MainCharacter';
import {Footprint} from '../components/Props';
import {Leaf} from '../components/Environment';
import {lerp, useSceneTime} from '../utils/anim';

/**
 * BEAT 7 (Panel 7) — Mengikuti jejak. 48,7-51,0 s (lokal 0-2,3).
 * Tracking dari belakang karakter, lorong sempit (pagar kanan, semak kiri), senter jadi sumber cahaya, daun foreground.
 */
const VPL: Pt = [600, 780];

export const FollowingScene: React.FC = () => {
  const {f, t} = useSceneTime();
  const pal = palAt(1);
  const k = t / 2.3;
  const cx = lerp(330, 372, k);
  const cy = lerp(1900, 1790, k);
  const sc = lerp(0.96, 0.84, k);
  const base = poseWalk(f, 0.13);
  const pose: Pose = {...base, armR: [48 + Math.sin(f * 0.13) * 4, 34], lean: 4, headRot: Math.sin(t * 1.6) * 9, armL: [base.armL[0] * 0.5, 14]};
  const tip = armTip({x: cx, y: cy, scale: sc, dir: 1}, pose, 'R', 56);
  const ang = (Math.atan2(VPL[1] + 140 - tip.y, VPL[0] - tip.x) * 180) / Math.PI;
  const cam: CamKey[] = [
    {t: 0, cx: 560, cy: 1120, zoom: 1.0},
    {t: 2.3, cx: 590, cy: 1010, zoom: 1.22, ease: 'io'},
  ];
  const prints = Array.from({length: 7}).map((_, i) => {
    const u = 1 - Math.pow(0.7, i);
    return {x: lerp(570, VPL[0] + 6, u), y: lerp(1540, VPL[1] + 70, u), s: lerp(1.1, 0.14, u)};
  });
  const bushes: Array<[number, number, number]> = [[160, 1500, 1.1], [330, 1180, 0.8], [440, 1000, 0.55], [520, 900, 0.38]];
  return (
    <Camera keys={cam} handheld={2.2}>
      <Layer depth={0.2}>
        <Stage>
          <defs>
            <linearGradient id="fSky" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0" stopColor="#060A24" />
              <stop offset="1" stopColor="#2A2564" />
            </linearGradient>
          </defs>
          <rect x={-700} y={-700} width={2480} height={1500} fill="url(#fSky)" />
          <circle cx={880} cy={200} r={44} fill="#FFF4C8" opacity={0.85} />
          {Array.from({length: 24}).map((_, i) => <circle key={i} cx={(i * 97) % 1100} cy={(i * 53) % 560} r={2} fill="#fff" opacity={0.6} />)}
        </Stage>
      </Layer>
      <Layer depth={0.7}>
        <Stage>
          <rect x={-700} y={700} width={2480} height={150} fill={pal.far} opacity={0.9} />
          {[[40, 520, 150], [820, 480, 160], [980, 560, 120]].map(([x, y, r], i) => <circle key={i} cx={x} cy={y} r={r} fill={pal.leafShade} />)}
          <Box3D x={520} y={640} w={160} h={170} k={0.5} vp={VPL} front={pal.wall} side={pal.wallShade} top={pal.roofShade}>
            <polygon points="505,640 695,640 640,585 560,585" fill={pal.roof} stroke="#05060F" strokeWidth={5} />
            <rect x={580} y={700} width={44} height={110} fill={pal.door} stroke="#05060F" strokeWidth={4} />
          </Box3D>
        </Stage>
      </Layer>
      <Layer depth={1}>
        <Stage>
          <rect x={-700} y={780} width={2480} height={1500} fill={pal.grassShade} />
          <PerspFloor vp={VPL} nearY={1920} farY={880} x0={230} x1={980} cols={6} rows={12} a="#4B3C34" b="#43352E" grout="rgba(0,0,0,0.12)" gw={1} />
          {prints.map((p, i) => <Footprint key={i} x={p.x} y={p.y} rot={-6} scale={p.s} tilt={0.55} opacity={0.9} />)}
          <FenceLine from={[1330, 1780]} vp={VPL} n={9} h0={300} pal={NIGHT} r={0.74} />
          {bushes.map(([x, y, s], i) => <Bush key={i} x={x} y={y} s={s} pal={pal} t={t} seed={i + 20} leaves={8} spread={110} />)}
          <MainCharacter x={cx} y={cy} scale={sc} expr={exprTrack(t, [[0, 'nervous']])} pose={pose} back brightness={0.62} flashlight="R" feet={{L: 'sandal', R: 'bare'}} />
          <Beam x={tip.x} y={tip.y} angle={ang} len={760} spread={20} intensity={0.75} id="wBeam" flicker={Math.sin(f * 2.1) > 0.97 ? 0.25 : 0} />
          <Pool x={VPL[0] - 20} y={VPL[1] + 190} rx={300} ry={110} intensity={0.75} id="wPool" />
        </Stage>
      </Layer>
      <Layer depth={1.7}>
        <Stage>
          {[[-30, 1990, 6, 1.7], [140, 2040, 2, 1.4], [1090, 2000, -8, 1.6], [940, 2060, -2, 1.3]].map(([x, y, r, s], i) => (
            <g key={i} transform={`translate(${Math.sin(t * 2.4 + i) * 8},0)`}>
              <Leaf x={x} y={y} rot={r} len={380 * s * 0.62} wid={90 * s * 0.6} fill={pal.leaf} shade={pal.leafShade} sway={Math.sin(t * 2.6 + i * 1.7) * 3} />
            </g>
          ))}
        </Stage>
      </Layer>
      <Overlay>
        <svg width={1080} height={1920} style={{position: 'absolute', left: 0, top: 0}}>
          <Dust t={t} count={16} x={0} y={600} w={1080} h={900} color="#D8FF8A" size={3} seed={31} opacity={0.5} />
        </svg>
      </Overlay>
      <Tint color="#3A3FA0" opacity={0.16} blend="soft-light" />
      <Vignette strength={0.62} color="2,3,20" />
    </Camera>
  );
};
void toward;
