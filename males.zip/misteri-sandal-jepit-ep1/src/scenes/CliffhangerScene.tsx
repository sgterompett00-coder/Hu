import React from 'react';
import {Camera, CamKey, Layer, Overlay} from '../components/Camera';
import {Stage} from '../components/Environment';
import {Exclaim, SpeedLines, Vignette} from '../components/Fx';
import {EXPR, MainCharacter, poseIdle} from '../components/MainCharacter';
import {clamp, pop, track, useSceneTime} from '../utils/anim';

/**
 * BEAT 9 (Panel 9) — Cliffhanger. 54,7-59,0 s (lokal 0-4,3).
 * Close-up ekstrem wajah terkejut, quick zoom-in, freeze frame, hard cut to black (BLACK_AT di Video.tsx). Tanpa narasi, tanpa pelaku.
 */
export const CliffhangerScene: React.FC = () => {
  const {f, t} = useSceneTime();
  const tt = Math.min(t, 1.25); // freeze: setelah 1,25 s tidak ada gerakan lagi
  const ff = Math.min(f, 38);
  const cam: CamKey[] = [
    {t: 0, cx: 540, cy: 960, zoom: 0.9},
    {t: 0.22, cx: 540, cy: 960, zoom: 1.12, ease: 'out'},
    {t: 1.25, cx: 540, cy: 960, zoom: 1.18, ease: 'lin'},
  ];
  const tremble = tt < 1.25 ? Math.sin(ff * 2.9) * 0.18 : 0;
  const expr = {...EXPR.shocked, px: tremble, py: tremble * 0.6, pupil: track(tt, [[0, 7], [0.25, 4.5], [1.25, 4.5]])};
  const pose = {...poseIdle(0), headRot: 3};
  const flash = clamp(1 - t / 0.12);
  return (
    <Camera keys={cam}>
      <Layer depth={0.5}>
        <Stage>
          <defs>
            <radialGradient id="cBG" cx="46%" cy="42%" r="75%">
              <stop offset="0" stopColor="#2A3F9A" />
              <stop offset="0.7" stopColor="#13206A" />
              <stop offset="1" stopColor="#070C34" />
            </radialGradient>
          </defs>
          <rect x={-700} y={-700} width={2480} height={3300} fill="url(#cBG)" />
        </Stage>
        <SpeedLines cx={500} cy={860} count={54} inner={330} outer={1900} color="#060A2E" opacity={0.7} seed={3} frame={0} width={12} />
        <SpeedLines cx={500} cy={860} count={30} inner={420} outer={1900} color="#6F86E0" opacity={0.35} seed={9} frame={0} width={5} />
      </Layer>
      <Layer depth={1}>
        <Stage>
          <MainCharacter x={500} y={2660} scale={3.3} expr={expr} pose={pose} shadow={0} />
          <g transform={`translate(0,0) scale(${pop(t, 0.12, 0.25)})`} style={{transformOrigin: '860px 380px'}}>
            <Exclaim x={860} y={380} scale={1.25} rot={8} />
          </g>
        </Stage>
      </Layer>
      <Vignette strength={0.5} color="0,0,12" />
      <Overlay style={{background: '#fff', opacity: flash * 0.9}} />
    </Camera>
  );
};
