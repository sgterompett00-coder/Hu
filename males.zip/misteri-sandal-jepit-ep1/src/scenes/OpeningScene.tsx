import React from 'react';
import {Camera, CamKey, Layer, Overlay} from '../components/Camera';
import {ExtFar, ExtGround, ExtHouse, ExtSky, Stage, Bush} from '../components/Environment';
import {palAt} from '../components/Environment';
import {Dust, ImpactLines, QMark, Tint, Vignette} from '../components/Fx';
import {MainCharacter, basePose, blendPose, exprTrack, poseIdle, poseWalk, Pose} from '../components/MainCharacter';
import {clamp, ease, lerp, pop, track, useSceneTime} from '../utils/anim';
import {VP_EXT} from '../components/Environment';

/**
 * BEAT 1 (Panel 1-2) — Sandal yang hilang. 0,0-11,2 s.
 * wide establishing -> low-angle tracking -> tilt-down ke kaki (satu sandal, satu telanjang) -> close-up bingung.
 */
const DOOR = {x: 310, y: 1010};
const pathX = (y: number) => VP_EXT[0] + ((DOOR.x - VP_EXT[0]) * (y - VP_EXT[1])) / (DOOR.y - VP_EXT[1]);
const scaleAt = (y: number) => (y - VP_EXT[1]) * 0.00126;
const STOP_Y = 1500;

const CAM: CamKey[] = [
  {t: 0, cx: 540, cy: 930, zoom: 1},
  {t: 3.0, cx: 480, cy: 1060, zoom: 1.2, ease: 'io'},
  {t: 5.3, cx: 450, cy: 1160, zoom: 1.35, ease: 'io'},
  {t: 5.9, cx: 450, cy: 1160, zoom: 1.35},
  {t: 7.2, cx: 434, cy: 1440, zoom: 3.7, ease: 'io'},
  {t: 8.7, cx: 434, cy: 1440, zoom: 3.8, ease: 'lin'},
  {t: 9.7, cx: 452, cy: 1090, zoom: 2.6, ease: 'io'},
  {t: 11.2, cx: 452, cy: 1085, zoom: 2.85, ease: 'lin'},
];

export const OpeningScene: React.FC = () => {
  const {f, t} = useSceneTime();
  const pal = palAt(0);
  const doorOpen = track(t, [[0.4, 0], [1.0, 1], [2.8, 1], [3.5, 0, 'in']]);
  const u = ease('io', clamp((t - 0.9) / 4.3));
  const y = lerp(DOOR.y, STOP_Y, u);
  const x = pathX(y);
  const sc = scaleAt(y);
  const appear = t >= 0.9;
  const walking = t < 5.2;
  const walkP = poseWalk(f, 0.2);
  const stopK = ease('io', clamp((t - 4.85) / 0.35));
  let pose: Pose = walking ? blendPose(walkP, poseIdle(f), stopK) : poseIdle(f);
  if (t >= 5.2) {
    // menunduk, memeriksa kaki, angkat kaki telanjang, garuk kepala
    const look = ease('io', clamp((t - 5.55) / 0.5));
    const lift = track(t, [[7.5, 0], [7.9, 1, 'out'], [8.5, 0.3], [8.9, 1], [9.4, 0]]);
    const scratch = ease('io', clamp((t - 9.6) / 0.4));
    const wig = Math.sin(t * 22) * 6 * scratch;
    pose = {
      ...pose, lean: lerp(pose.lean, 6, look), headRot: lerp(pose.headRot, 12, look) + Math.sin(t * 3) * 1.2 * scratch + (t > 10 ? 6 : 0),
      legR: [lerp(0, 26, lift), lerp(0, -58, lift)],
      armR: [lerp(pose.armR[0], 136 + wig, scratch), lerp(pose.armR[1], 64, scratch)],
    };
  }
  const sy = track(t, [[5.1, 1], [5.25, 0.92], [5.5, 1.05, 'out'], [5.85, 1]]);
  const expr = exprTrack(t, [[0, 'smug'], [3.0, 'confident'], [5.15, 'neutral'], [5.45, 'confused'], [9.7, 'confused'], [10.4, 'curious']], 0.25);

  return (
    <Camera keys={CAM} handheld={t < 5.3 ? 1.2 : 0}>
      <Layer depth={0.15}><ExtSky k={0} t={t} /></Layer>
      <Layer depth={0.45}><ExtFar k={0} /></Layer>
      <Layer depth={1}><ExtGround k={0} /></Layer>
      <Layer depth={0.95}><ExtHouse k={0} t={t} doorOpen={doorOpen} /></Layer>
      <Layer depth={1}>
        <Stage>
          {appear && (
            <MainCharacter x={x} y={y} scale={sc} expr={expr} pose={pose} sy={sy} feet={{L: 'sandal', R: 'bare'}} />
          )}
          {t > 5.2 && <ImpactLines x={x + 170 * sc} y={y - 230 * sc} scale={sc * 1.3} t={t} start={5.2} />}
          {t > 6.6 && t < 9.8 && <ImpactLines x={x + 120 * sc} y={y - 70 * sc} rot={-8} scale={sc * 1.2} t={t} start={6.6} />}
          {t > 10.2 && <g transform={`translate(${x + 120 * sc},${y - 700 * sc})`}><QMark x={0} y={0} scale={0.55 * pop(t, 10.2, 0.3)} rot={8} /></g>}
        </Stage>
      </Layer>
      <Layer depth={1.45}>
        <Stage>
          <Bush x={20} y={1960} s={1.5} pal={pal} t={t} seed={3} leaves={8} spread={110} />
          <Bush x={1070} y={1950} s={1.35} pal={pal} t={t} seed={7} leaves={8} spread={110} />
        </Stage>
      </Layer>
      <Overlay>
        <svg width={1080} height={1920} style={{position: 'absolute', left: 0, top: 0}}>
          <Dust t={t} count={22} x={0} y={200} w={1080} h={1200} color="#FFF8D0" size={3.5} seed={5} opacity={0.55} />
        </svg>
      </Overlay>
      <Tint color="#FFE7A8" opacity={0.1} blend="soft-light" />
      <Vignette strength={0.28} color="40,30,10" />
    </Camera>
  );
};
