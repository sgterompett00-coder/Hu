import React from 'react';
import {Pal, Pt, Room} from '../components/Environment';

/** Geometri ruangan bersama (Beat 2 & 3). Dinding belakang x 116..964, y 412..1388. */
export const ROOM_VP: Pt = [540, 860];
export const ROOM_NEAR = {x: -520, y: -260, w: 2120, h: 2440};
export const ROOM_K = 0.4;
export const WALL_BASE = 1388;
/** Skala karakter menurut kedalaman (y lantai). */
export const roomScale = (y: number): number => (y - 860) * 0.00105;

type RoomKind = 'bedroom' | 'kitchen' | 'living' | 'shop';
const STYLE: Record<RoomKind, {wall?: string; a?: string; b?: string; cols: number; rows: number}> = {
  bedroom: {wall: '#DCE9F7', a: '#C99A6B', b: '#BD8B5C', cols: 14, rows: 9},
  living: {wall: '#F6E8C8', a: '#E3C9A0', b: '#D8BA8E', cols: 12, rows: 9},
  kitchen: {wall: '#D9EEDD', a: '#F4F4F2', b: '#BFCAD2', cols: 12, rows: 9},
  shop: {wall: '#FFF1D6', a: '#E7D3B3', b: '#D9C09A', cols: 12, rows: 9},
};
export const RoomBase: React.FC<{kind: RoomKind; pal: Pal}> = ({kind, pal}) => {
  const st = STYLE[kind];
  return <Room vp={ROOM_VP} near={ROOM_NEAR} k={ROOM_K} pal={pal} wallColor={st.wall} floorA={st.a} floorB={st.b} cols={st.cols} rows={st.rows} />;
};
