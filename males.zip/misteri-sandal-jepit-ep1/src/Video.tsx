import React from 'react';
import {AbsoluteFill, Audio, Sequence, interpolate, staticFile, useCurrentFrame} from 'remotion';
import {AUDIO_OFFSET, BLACK_AT, MUSIC_OFF_AT, SCENES, SceneId, secToFrame} from './data/beats';
import {MUSIC, PLAY_MUSIC, PLAY_NARRATION, PLAY_SFX, SOUND_CUES} from './data/soundCues';
import {Subtitle} from './components/Subtitle';
import {OpeningScene} from './scenes/OpeningScene';
import {SearchScene} from './scenes/SearchScene';
import {NewSandalScene} from './scenes/NewSandalScene';
import {NightScene} from './scenes/NightScene';
import {FootprintScene} from './scenes/FootprintScene';
import {FollowingScene} from './scenes/FollowingScene';
import {DiscoveryScene} from './scenes/DiscoveryScene';
import {CliffhangerScene} from './scenes/CliffhangerScene';

const SCENE_COMPONENTS: Partial<Record<SceneId, React.FC>> = {
  opening: OpeningScene,
  search: SearchScene,
  newSandal: NewSandalScene,
  night: NightScene,
  footprint: FootprintScene,
  following: FollowingScene,
  discovery: DiscoveryScene,
  cliffhanger: CliffhangerScene,
};

const Black: React.FC = () => {
  const frame = useCurrentFrame();
  return frame >= secToFrame(BLACK_AT) ? <AbsoluteFill style={{backgroundColor: '#000'}} /> : null;
};

/** Susunan lapisan: scene -> subtitle -> audio -> layar hitam akhir. Tidak ada header/judul. */
export const SandalVideo: React.FC = () => {
  return (
    <AbsoluteFill style={{backgroundColor: '#000'}}>
      {SCENES.map((s) => {
        const C = SCENE_COMPONENTS[s.id];
        if (!C) return null;
        const from = secToFrame(s.start);
        return (
          <Sequence key={s.id} from={from} durationInFrames={secToFrame(s.end) - from} name={s.id}>
            <C />
          </Sequence>
        );
      })}
      <Subtitle />

      {PLAY_NARRATION && (
        <Sequence from={secToFrame(AUDIO_OFFSET)} layout="none" name="narasi">
          <Audio src={staticFile('narasi.mp3')} volume={1} />
        </Sequence>
      )}
      {PLAY_SFX &&
        SOUND_CUES.map((c) => (
          <Sequence key={c.id} from={secToFrame(c.t)} durationInFrames={Math.max(1, secToFrame(c.dur))} layout="none" name={`sfx-${c.id}`}>
            <Audio src={staticFile(c.file)} volume={c.volume} loop={c.loop} />
          </Sequence>
        ))}
      {PLAY_MUSIC && (
        <Audio
          src={staticFile(MUSIC.file)}
          volume={(f) => interpolate(f, [0, 20, secToFrame(MUSIC_OFF_AT) - 6, secToFrame(MUSIC_OFF_AT)], [0, MUSIC.volume, MUSIC.volume, 0], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'})}
        />
      )}
      <Black />
    </AbsoluteFill>
  );
};
