/**
 * captions.ts — subtitle dari SRT narasi.
 * - SRT_CUES = isi captions.srt apa adanya (timestamp dari audio asli pengguna).
 * - Waktu per KATA dibagi proporsional jumlah karakter di dalam tiap cue (PROVISIONAL).
 * - Teks subtitle mengikuti NASKAH FINAL ("nggak", tanda "..."), bukan ejaan SRT.
 * Semua fungsi murni & deterministik.
 */
import {FPS} from './beats';

export type SrtCue = {index: number; start: number; end: number; text: string};

export const SRT_CUES: SrtCue[] = [
  {index: 1, start: 0.08, end: 4.74, text: 'Pernah enggak sih, kamu punya sepasang sandal, tapi yang hilang justru cuma'},
  {index: 2, start: 4.74, end: 5.2, text: 'sebelah?'},
  {index: 3, start: 5.92, end: 8.02, text: 'Awalnya aku pikir ini hal biasa,'},
  {index: 4, start: 8.66, end: 14.26, text: 'sampai kejadian ini terus berulang. Aku langsung mencari ke seluruh rumah. Di'},
  {index: 5, start: 14.26, end: 20.0, text: 'kamar enggak ada, di dapur enggak ada, bahkan di bawah kasur juga enggak ada. Aku'},
  {index: 6, start: 20.0, end: 25.44, text: 'sampai curiga, jangan-jangan sandalku punya kaki sendiri. Akhirnya, aku beli'},
  {index: 7, start: 25.44, end: 32.259, text: 'sandal baru. Tapi besoknya, satu sandal hilang lagi. Aku beli lagi, hilang lagi.'},
  {index: 8, start: 32.259, end: 36.48, text: 'Sampai-sampai aku merasa ada seseorang yang sengaja mengincarku.'},
  {index: 9, start: 37.2, end: 42.78, text: 'Sampai suatu malam, aku melihat sesuatu yang aneh di depan rumah. Ada jejak sandal'},
  {index: 10, start: 42.78, end: 48.06, text: 'yang mengarah ke belakang rumah. Dan anehnya, jejak itu cuma satu.'},
  {index: 11, start: 48.74, end: 54.1, text: 'Aku mengikuti jejak itu, sampai akhirnya menemukan sesuatu yang bikin aku'},
  {index: 12, start: 54.1, end: 54.62, text: 'merinding.'},
];

/** Penyesuaian ejaan SRT -> naskah final. */
const NASKAH_FIX: Array<[RegExp, string]> = [
  [/enggak/gi, 'nggak'],
  [/biasa,/g, 'biasa…'],
  [/curiga,/g, 'curiga'],
  [/Akhirnya,/g, 'Akhirnya'],
  [/anehnya,/g, 'anehnya…'],
  [/itu, sampai/g, 'itu… sampai'],
];
export const toNaskah = (s: string): string => NASKAH_FIX.reduce((acc, [re, rep]) => acc.replace(re, rep), s);

/** Kata yang disorot kuning. */
const KEYWORDS = ['sebelah', 'hilang', 'kasur', 'sendiri', 'mengincarku', 'jejak', 'cuma', 'satu', 'merinding'];
const bare = (w: string): string => w.toLowerCase().replace(/[.,?!…]/g, '');

export type Word = {text: string; start: number; end: number; keyword: boolean};

/** Bagi durasi tiap cue ke kata-katanya secara proporsional berdasarkan jumlah karakter. */
export function buildWords(cues: SrtCue[] = SRT_CUES): Word[] {
  const out: Word[] = [];
  for (const cue of cues) {
    const tokens = toNaskah(cue.text).replace(/\s+/g, ' ').trim().split(' ');
    const total = tokens.reduce((a, t) => a + t.length, 0);
    let cursor = cue.start;
    for (const tok of tokens) {
      const dur = ((cue.end - cue.start) * tok.length) / total;
      out.push({text: tok, start: cursor, end: cursor + dur, keyword: KEYWORDS.includes(bare(tok))});
      cursor += dur;
    }
  }
  return out;
}

export type Phrase = {words: Word[]; start: number; end: number; startFrame: number; endFrame: number};

const MAX_WORDS = 5;
const GAP = 0.35;

/** Kelompokkan kata jadi frasa pendek (maks 5 kata, maks 2 baris di layar). */
export function buildPhrases(words: Word[] = buildWords()): Phrase[] {
  const clauses: Word[][] = [];
  let cur: Word[] = [];
  words.forEach((w, i) => {
    cur.push(w);
    const next = words[i + 1];
    const endsClause = /[.,?!…]$/.test(w.text);
    if (endsClause || !next || next.start - w.end > GAP) {
      clauses.push(cur);
      cur = [];
    }
  });
  const chunks: Word[][] = [];
  for (const c of clauses) {
    const parts = Math.ceil(c.length / MAX_WORDS);
    const size = Math.ceil(c.length / parts);
    for (let i = 0; i < c.length; i += size) chunks.push(c.slice(i, i + size));
  }
  return chunks.map((ws, i) => {
    const start = ws[0].start;
    const nextStart = chunks[i + 1] ? chunks[i + 1][0].start : Infinity;
    const end = Math.min(ws[ws.length - 1].end + 0.2, nextStart);
    return {words: ws, start, end, startFrame: Math.round(start * FPS), endFrame: Math.round(end * FPS)};
  });
}

export const WORDS: Word[] = buildWords();
export const PHRASES: Phrase[] = buildPhrases(WORDS);
