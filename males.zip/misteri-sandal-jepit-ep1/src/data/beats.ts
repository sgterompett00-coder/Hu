/**
 * beats.ts — timeline utama video.
 * Semua waktu dalam DETIK pada timeline video (narasi mulai di AUDIO_OFFSET).
 * Pembagian beat mengikuti SRT narasi. Pembagian per kalimat di dalam satu cue SRT
 * adalah estimasi proporsional per karakter (PROVISIONAL) sampai audio final dicek.
 */
export const FPS = 30;
export const WIDTH = 1080;
export const HEIGHT = 1920;
export const secToFrame = (s: number): number => Math.round(s * FPS);

/** Geser narasi terhadap video (detik). 0 = narasi.mp3 mulai di frame 0. Tidak boleh negatif. */
export const AUDIO_OFFSET = 0;
/** true = waktu per kalimat masih estimasi proporsional dari SRT (belum word-level). */
export const TIMING_PROVISIONAL = true;

export type SceneId =
  | 'opening'
  | 'search'
  | 'newSandal'
  | 'night'
  | 'footprint'
  | 'following'
  | 'discovery'
  | 'cliffhanger';

export type Beat = {
  id: number;
  scene: SceneId;
  panel: string;
  label: string;
  start: number;
  end: number;
  narration: string;
};

export const BEATS: Beat[] = [
  {id: 1, scene: 'opening', panel: '1-2', label: 'Sandal yang hilang', start: 0.0, end: 11.2,
    narration: 'Pernah nggak sih, kamu punya sepasang sandal, tapi yang hilang justru cuma sebelah? Awalnya aku pikir ini hal biasa... sampai kejadian ini terus berulang.'},
  {id: 2, scene: 'search', panel: '3', label: 'Mencari ke seluruh rumah', start: 11.2, end: 24.1,
    narration: 'Aku langsung mencari ke seluruh rumah. Di kamar nggak ada, di dapur nggak ada, bahkan di bawah kasur juga nggak ada. Aku sampai curiga jangan-jangan sandalku punya kaki sendiri.'},
  {id: 3, scene: 'newSandal', panel: '4', label: 'Sandal baru, masalah lama', start: 24.1, end: 37.2,
    narration: 'Akhirnya aku beli sandal baru. Tapi besoknya, satu sandal hilang lagi. Aku beli lagi, hilang lagi. Sampai-sampai aku merasa ada seseorang yang sengaja mengincarku.'},
  {id: 4, scene: 'night', panel: '5', label: 'Sesuatu di depan rumah', start: 37.2, end: 41.6,
    narration: 'Sampai suatu malam, aku melihat sesuatu yang aneh di depan rumah.'},
  {id: 5, scene: 'footprint', panel: '6', label: 'Jejak sandal', start: 41.6, end: 45.3,
    narration: 'Ada jejak sandal yang mengarah ke belakang rumah.'},
  {id: 6, scene: 'footprint', panel: '6', label: 'Jejak yang aneh', start: 45.3, end: 48.7,
    narration: 'Dan anehnya... jejak itu cuma satu.'},
  {id: 7, scene: 'following', panel: '7', label: 'Mengikuti jejak', start: 48.7, end: 51.0,
    narration: 'Aku mengikuti jejak itu...'},
  {id: 8, scene: 'discovery', panel: '8', label: 'Penemuan misterius', start: 51.0, end: 54.7,
    narration: '...sampai akhirnya menemukan sesuatu yang bikin aku merinding.'},
  {id: 9, scene: 'cliffhanger', panel: '9', label: 'Cliffhanger', start: 54.7, end: 59.0,
    narration: ''},
];

export type SceneDef = {id: SceneId; start: number; end: number; beats: number[]};

/** Satu scene = satu komponen. Beat 5 & 6 berbagi FootprintScene. Scene 3 memakai napas 36,5-37,2 s. */
export const SCENES: SceneDef[] = [
  {id: 'opening', start: 0.0, end: 11.2, beats: [1]},
  {id: 'search', start: 11.2, end: 24.1, beats: [2]},
  {id: 'newSandal', start: 24.1, end: 37.2, beats: [3]},
  {id: 'night', start: 37.2, end: 41.6, beats: [4]},
  {id: 'footprint', start: 41.6, end: 48.7, beats: [5, 6]},
  {id: 'following', start: 48.7, end: 51.0, beats: [7]},
  {id: 'discovery', start: 51.0, end: 54.7, beats: [8]},
  {id: 'cliffhanger', start: 54.7, end: 59.0, beats: [9]},
];

export const TOTAL_SECONDS = 59.0;
export const TOTAL_FRAMES = secToFrame(TOTAL_SECONDS);
/** Hard cut to black di Beat 9 (detik). Setelah ini layar hitam + hening. */
export const BLACK_AT = 58.4;
/** Detik saat musik harus mati total (sudden silence). */
export const MUSIC_OFF_AT = 54.55;
