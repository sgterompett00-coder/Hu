/**
 * layout.ts — koordinat eksplisit pada kanvas 1080 x 1920 (px, pojok kiri-atas).
 * Zona aman: aksi utama y 250..1380; hindari y < 220 dan y > 1650 (UI platform).
 * Scene memakai kotak ini sebagai jangkar komposisi; detail kecil dihitung di dalam scene.
 */
export type Box = {x: number; y: number; w: number; h: number};
export const box = (x: number, y: number, w: number, h: number): Box => ({x, y, w, h});

export const LAYOUT = {
  canvas: box(0, 0, 1080, 1920),
  safe: box(60, 220, 960, 1430),
  subtitle: box(90, 1420, 900, 200),

  character: {
    standing: box(300, 560, 480, 720), // Beat 1,2,4
    crouch: box(240, 640, 600, 560), // Beat 2,5
    finalCloseUp: box(60, 260, 960, 1050), // Beat 9
  },

  houseExteriorDay: box(0, 200, 1080, 1150), // Beat 1
  houseInterior: box(0, 300, 1080, 1100), // Beat 2
  bedroom: box(0, 300, 1080, 1100),
  kitchen: box(0, 300, 1080, 1100),
  shop: box(0, 300, 1080, 1100), // Beat 3
  nightEnvironment: box(0, 0, 1080, 1500), // Beat 4-8

  bed: box(380, 760, 700, 420),
  refrigerator: box(700, 420, 300, 780),
  sofa: box(60, 820, 620, 360),

  sandalPairHeld: box(560, 620, 360, 420), // Beat 3
  singleSandalFoot: box(140, 900, 380, 260), // Beat 1
  singleSandalBush: box(220, 640, 640, 360), // Beat 8
  calendar: box(560, 260, 460, 360), // Beat 3

  flashlightCone: box(560, 760, 420, 560), // Beat 4,7
  footprints: box(140, 300, 800, 980), // Beat 5,6
  bushesForeground: box(0, 1000, 1080, 500), // Beat 7,8
} as const;

export const centerOf = (b: Box) => ({x: b.x + b.w / 2, y: b.y + b.h / 2});
