/**
 * soundCues.ts — cue sheet SFX + slot musik latar.
 * Proyek TIDAK berisi file audio SFX/musik. Taruh file buatanmu di public/sounds/ dan public/music/
 * dengan nama persis seperti kolom `file`, lalu ubah PLAY_SFX / PLAY_MUSIC jadi true.
 */
export const PLAY_NARRATION = true; // public/narasi.mp3 wajib ada
export const PLAY_SFX = false; // true setelah semua file di public/sounds/ tersedia
export const PLAY_MUSIC = false; // true setelah public/music/bgm.mp3 tersedia

export type SoundCue = {
  id: string;
  t: number; // detik, timeline video
  name: string;
  scene: string; // beat
  dur: number; // detik
  vol: 'rendah' | 'sedang' | 'tinggi';
  volume: number; // 0..1 relatif terhadap narasi
  placement: string;
  file: string;
  loop?: boolean;
};

const V = {rendah: 0.18, sedang: 0.4, tinggi: 0.7} as const;
const cue = (
  id: string, t: number, name: string, scene: string, dur: number,
  vol: keyof typeof V, placement: string, loop = false,
): SoundCue => ({id, t, name, scene, dur, vol, volume: V[vol], placement, file: `sounds/${id}.mp3`, loop});

export const SOUND_CUES: SoundCue[] = [
  cue('morning-ambience', 0.0, 'Morning ambience', '1', 11.2, 'rendah', 'Loop, fade out di akhir Beat 1', true),
  cue('bird-chirping', 0.5, 'Bird chirping', '1', 6.0, 'rendah', 'Kiri-kanan, tipis'),
  cue('door-opening', 1.5, 'Door opening', '1', 1.2, 'sedang', 'Sinkron pintu terbuka'),
  cue('footsteps-day', 2.0, 'Footsteps', '1', 3.2, 'sedang', 'Sinkron langkah menuju halaman'),
  cue('comedic-pop-1', 5.3, 'Comedic pop', '1', 0.5, 'tinggi', 'Saat sadar sandal sebelah hilang'),
  cue('drawer-opening', 12.0, 'Drawer opening', '2', 1.0, 'sedang', 'Buka lemari'),
  cue('object-movement', 14.4, 'Object movement', '2', 1.0, 'sedang', 'Angkat bantal (kamar)'),
  cue('refrigerator-opening', 15.7, 'Refrigerator opening', '2', 1.5, 'sedang', 'Buka kulkas (dapur)'),
  cue('mattress-movement', 17.6, 'Mattress movement', '2', 1.5, 'sedang', 'Kasur diangkat'),
  cue('comedic-pop-2', 19.6, 'Comedic pop', '2', 0.5, 'sedang', 'Tidak ada sandal di bawah kasur'),
  cue('thinking-sound', 21.5, 'Short thinking sound', '2', 1.0, 'rendah', 'Saat duduk berpikir'),
  cue('shop-ambience', 24.3, 'Shop ambience', '3', 7.0, 'rendah', 'Fade turun menuju montage'),
  cue('payment-sound', 26.0, 'Payment sound', '3', 0.6, 'sedang', 'Bayar'),
  cue('calendar-flip-1', 27.6, 'Calendar flip', '3', 0.7, 'sedang', 'Besoknya...'),
  cue('comedic-impact-1', 29.6, 'Comedic impact', '3', 0.4, 'tinggi', 'Sandal tinggal sebelah (1)'),
  cue('whoosh-1', 30.0, 'Whoosh', '3', 0.5, 'sedang', 'Montage (1)'),
  cue('calendar-flip-2', 31.0, 'Calendar flip', '3', 0.7, 'sedang', 'Montage (2)'),
  cue('comedic-impact-2', 31.8, 'Comedic impact', '3', 0.4, 'tinggi', 'Sandal tinggal sebelah (2)'),
  cue('whoosh-2', 32.4, 'Whoosh', '3', 0.5, 'sedang', 'Montage (3)'),
  cue('suspense-transition', 35.0, 'Suspense transition', '3', 2.2, 'sedang', 'Warna mulai redup menuju malam'),
  cue('night-ambience', 37.2, 'Night ambience', '4-8', 17.4, 'rendah', 'Loop sampai Beat 8', true),
  cue('crickets', 37.2, 'Crickets', '4-8', 17.4, 'rendah', 'Loop, di bawah ambience', true),
  cue('soft-wind', 38.0, 'Soft wind', '4', 4.0, 'rendah', 'Bertahap'),
  cue('flashlight-click', 39.6, 'Flashlight click', '4', 0.3, 'sedang', 'Saat senter menyala'),
  cue('suspense-drone', 40.0, 'Suspense drone', '4-8', 14.5, 'rendah', 'Naik pelan sampai Beat 8'),
  cue('sand-movement', 42.5, 'Sand movement', '5', 2.0, 'rendah', 'Senter menyapu tanah'),
  cue('cinematic-hit', 44.5, 'Small cinematic hit', '5', 0.5, 'sedang', 'Jejak terlihat jelas'),
  cue('low-rumble', 46.0, 'Low rumble', '6', 2.0, 'sedang', 'Jejak cuma satu'),
  cue('heartbeat', 47.2, 'Subtle heartbeat', '6', 2.5, 'rendah', 'Wajah takut'),
  cue('footsteps-night', 49.0, 'Footsteps', '7', 2.0, 'sedang', 'Langkah pelan'),
  cue('leaves-rustling', 49.5, 'Leaves rustling', '7-8', 4.0, 'sedang', 'Semak bergerak'),
  cue('reverse-whoosh', 53.6, 'Reverse whoosh', '8', 1.0, 'sedang', 'Sebelum hard cut'),
  cue('final-impact', 54.7, 'Final impact + low boom', '9', 1.5, 'tinggi', 'Komedi-kejut berubah jadi suspense hit'),
];

/** Slot musik latar (file buatanmu). Mati total di MUSIC_OFF_AT (sudden silence). */
export const MUSIC = {
  file: 'music/bgm.mp3',
  volume: 0.16,
  note: 'Ringan-santai (B1) -> playful (B2) -> ritme cepat (B3) -> suspense (B4-6) -> cinematic tension (B7-8) -> hening (B9)',
};
