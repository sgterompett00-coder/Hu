# Misteri Sandal Jepit — Episode 1: Sandal Sebelah

Video animasi Remotion (React + TypeScript), vertikal 9:16, 1080x1920, 30 fps, ±59 detik.
Gaya: karakter kartun **2D** (rig SVG) di atas lingkungan **2.5D berperspektif** (lantai/dinding/rumah berperspektif satu titik hilang, parallax kamera, depth of field).
Tidak ada header, judul, nomor panel, atau progress bar. Hanya subtitle narasi.

## STATUS JUJUR (baca dulu)
- Kode ditulis dan setiap adegan sudah dicek visual lewat render frame lokal memakai **shim** pengganti API Remotion (React + Chromium). Itu membuktikan komposisi, animasi, dan subtitle jalan.
- **Belum pernah dirender dengan Remotion asli** (`npm install` tidak bisa dijalankan di lingkungan pembuatan: tanpa internet). Jadi `npm run render` belum diuji. Jika ada error, kirim pesannya ke saya.
- TypeScript hanya dicek sebagian (dengan stub tipe). Jalankan `npm run typecheck` di komputermu.
- Narasi, SFX, dan musik **tidak disertakan** (kamu yang menyediakan).
- Timing per kalimat di dalam satu cue SRT adalah **estimasi proporsional per karakter (PROVISIONAL)**. Lihat `TIMING_PROVISIONAL` di `src/data/beats.ts`.

## Menjalankan di Windows (pemula)
1. Pasang **Node.js LTS** dari https://nodejs.org (pilih tombol LTS, Next terus sampai selesai). Restart komputer jika perlu.
2. **Ekstrak ZIP** (klik kanan -> Extract All).
3. Buka folder hasil ekstrak (yang berisi `package.json`).
4. Klik kolom alamat folder, ketik `cmd`, tekan Enter. Terminal terbuka di folder itu.
5. Ketik `npm install`, Enter. Tunggu sampai selesai (bisa beberapa menit; internet dibutuhkan).
6. Salin **narasi.mp3** ke folder `public`. Namanya harus persis `narasi.mp3`.
7. (Opsional) Salin SFX ke `public/sounds` sesuai daftar di `public/sounds/DAFTAR_SFX.txt`, lalu ubah `PLAY_SFX = true` di `src/data/soundCues.ts`.
8. (Opsional) Salin musik ke `public/music/bgm.mp3`, lalu ubah `PLAY_MUSIC = true`.
9. Jalankan `npm run dev`. Browser membuka **Remotion Studio** (preview).
10. Di Studio, pilih komposisi **SandalSebelah**, tekan spasi untuk memutar, geser timeline untuk memeriksa tiap adegan.
11. Untuk hasil akhir, tutup preview (Ctrl+C di terminal) lalu jalankan `npm run render`.
12. Hasil MP4 ada di folder `out/sandal-sebelah.mp4`.

Untuk menguji satu frame saja: `npm run still` (hasil `out/frame.png`).
Tanpa narasi.mp3 dulu? Ubah `PLAY_NARRATION = false` di `src/data/soundCues.ts`.

## Struktur
```
public/            narasi.mp3 (kamu), sounds/, music/, images/
src/index.ts       registerRoot
src/Root.tsx       <Composition id="SandalSebelah">
src/Video.tsx      urutan scene (Sequence), subtitle, audio, layar hitam akhir
src/data/          beats.ts, captions.ts, soundCues.ts, layout.ts
src/components/    MainCharacter, Sandal, Subtitle, Camera, Environment, Props, Fx
src/scenes/        Opening, Search, NewSandal, Night, Footprint, Following, Discovery, Cliffhanger
captions.srt       SRT asli dari audio narasi
```

## Cara kerja timing
- `beats.ts`: 9 beat dan 8 scene dengan waktu dalam detik, mengikuti SRT (bukan timestamp naskah awal).
- `captions.ts`: cue SRT -> kata (proporsional jumlah karakter) -> frasa pendek maks 5 kata. Ejaan mengikuti **naskah final** ("nggak", "...").
- `AUDIO_OFFSET` (detik, `beats.ts`) menggeser narasi + subtitle bersamaan. Konversi frame: `Math.round(detik * 30)`.
- Jika audio aktual berbeda dari SRT, ubah angka di `SRT_CUES` / `SCENES` / `BEATS`; urutan cerita tidak berubah.
- Hard cut to black di `BLACK_AT` (58,4 s); total 59,0 s (`TOTAL_SECONDS`).

## Sound design
`src/data/soundCues.ts` berisi cue sheet lengkap (waktu, nama, beat, durasi, volume relatif, penempatan, nama file). Proyek tidak membuat audio apa pun. Musik diturunkan otomatis ke nol di `MUSIC_OFF_AT`.

## Aturan yang dijaga
Animasi deterministik (tanpa CSS animation, setTimeout, Math.random). Karakter selalu 2D. Pelaku pencuri sandal tidak pernah ditampilkan. Sandal selalu satu model: biru tua, tali Y (pajangan toko berwarna lain hanya sebagai dekor).
