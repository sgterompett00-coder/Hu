Taruh musik latar buatanmu sebagai bgm.mp3 di folder ini, lalu ubah PLAY_MUSIC = true di src/data/soundCues.ts.
Musik otomatis diturunkan ke 0 pada MUSIC_OFF_AT (sudden silence sebelum cliffhanger).
