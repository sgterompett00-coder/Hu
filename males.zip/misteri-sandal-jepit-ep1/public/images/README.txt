Folder aset gambar (opsional). Karakter & lingkungan versi ini digambar sebagai SVG vektor di dalam kode (src/components), jadi tidak butuh file gambar.
Jika kamu punya art karakter sendiri, ganti isi src/components/MainCharacter.tsx dengan <Img src={staticFile('images/...')} />.
